package smart.things;

import smart.Capability.CountBoats;
import smart.Capability.CountPeople;
import smart.Capability.SenseAndReportTemparature;
import util.Settings;

public class TempSensor extends Thing {

    public TempSensor(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new SenseAndReportTemparature(), Settings.MEASURE_TEMERATURE, "*", null);

    }

    public TempSensor(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new SenseAndReportTemparature(), Settings.MEASURE_TEMERATURE, "*", null);


    }
}
