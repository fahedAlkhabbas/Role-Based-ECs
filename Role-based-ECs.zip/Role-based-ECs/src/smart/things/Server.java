package smart.things;

import smart.Capability.StreamAdv;
import util.Settings;

public class Server extends Thing{

    public Server(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new StreamAdv(), Settings.STREAM_ADS, "*", null);

    }

    public Server(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new StreamAdv(), Settings.STREAM_ADS, "*", null);



    }


}
