package smart.things;

import smart.Capability.CountBoats;
import smart.Capability.CountPeople;
import util.Settings;

public class VirtualSensor extends Thing {

    public VirtualSensor(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new CountPeople(),Settings.STREAM_PEOPLE_COUNT, "*", null);

    }

    public VirtualSensor(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new CountPeople(),Settings.STREAM_PEOPLE_COUNT, "*", null);


    }
}