package smart.things;

import smart.Capability.ControlTemperature;
import util.Settings;

public class Conditioner extends Thing {

    public Conditioner(String n, String location) throws Exception {
        super(n, location, true, true, "*");
          addThingCapability(new ControlTemperature(), Settings.CONTROL_TِEMPERATURE, "*", null);


    }

    public Conditioner(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new ControlTemperature(), Settings.CONTROL_TِEMPERATURE, "*", null);


    }
}
