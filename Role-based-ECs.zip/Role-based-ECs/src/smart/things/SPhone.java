package smart.things;

import smart.Capability.StreamPresentation;
import smart.Capability.EndPresentation;
import util.Settings;

public class SPhone extends Thing {

    public SPhone(String n, String location) throws Exception {
        super(n, location, true, true, "100");
        addThingCapability(new EndPresentation(), Settings.END_PRESENTATION, "*", null);
        addThingCapability(new StreamPresentation(), Settings.STREAM_PRESENTATION, "*", null);



    }

    public SPhone(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new EndPresentation(), Settings.END_PRESENTATION, "*", null);
        addThingCapability(new StreamPresentation(), Settings.STREAM_PRESENTATION, "*", null);



    }
}
