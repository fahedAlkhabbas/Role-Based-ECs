package smart.things;

import com.intendico.gorite.Performer;
import com.intendico.gorite.Team;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import util.Settings;

import java.util.HashSet;
import java.util.concurrent.ConcurrentHashMap;

public class Thing extends Performer {
    ApplicationLevelAgent managingAgent;
    String location;
    String batteryLevel ;
    boolean connectionStatus = true;
    boolean operationalSatus = true;
    HashSet<String> capabilities = new HashSet<String>();
    HashSet<Team.TaskTeam> ParticipatingInECs = new HashSet<Team.TaskTeam>();
    ConcurrentHashMap<String, HashSet<String>> conflictingCapabilities = new ConcurrentHashMap<String, HashSet<String>>();

    public Thing(String n, String location, boolean operationSatus, boolean connectionStatus, String bLevel) {
        super(n);
        this.location = location;
        this.operationalSatus = operationSatus;
        this.connectionStatus = connectionStatus;
        this.batteryLevel = bLevel;
    }

    public HashSet<String> getCapabilities() {
        return capabilities;
    }

    public void setCapabilities(HashSet<String> capabilities) {
        this.capabilities = capabilities;
    }

    public ApplicationLevelAgent getManagingAgent() {
        return managingAgent;
    }

    public void setManagingAgent(ApplicationLevelAgent managingAgent) {
        this.managingAgent = managingAgent;
    }

    public ConcurrentHashMap<String, HashSet<String>> getConflictingCapabilities() {
        return conflictingCapabilities;
    }

    public void setConflictingCapabilities(ConcurrentHashMap<String, HashSet<String>> conflictingCapabilities) {
        this.conflictingCapabilities = conflictingCapabilities;
    }

    public void addThingCapability(String capability, HashSet<String> conflictingCaps) {
        capabilities.add(capability);
        if(conflictingCaps != null && conflictingCaps.size()>0){
            conflictingCapabilities.put(capability, conflictingCaps);
        }
    }


    public HashSet<Team.TaskTeam> getParticipatingInECs() {
        return ParticipatingInECs;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        if(!location.equals(this.location)){
            managingAgent.changeThingLocationListiner(this, location);
        }
        this.location = location;
    }

    public String getBatteryLevel() {
        return batteryLevel;
    }

    public void setBatteryLevel(String batteryLevel) {
        this.batteryLevel = batteryLevel;
    }

    public boolean isConnectionStatus() {
        return connectionStatus;
    }

    public void setConnectionStatus(boolean connectionStatus) {
        this.connectionStatus = connectionStatus;
        if (!connectionStatus)
            managingAgent.changeThingConnectivityStatusListiner(this, Settings.DISCONNECTED);

    }

    public boolean isOperationalSatus() {
        return operationalSatus;
    }

    public void setOperationalSatus(boolean operationalSatus) {
        try {
            this.operationalSatus = operationalSatus;
            if (!operationalSatus)
                managingAgent.changeThingOperationalStatusListiner(this, Settings.OFF);
        } catch (Exception e) {

            e.printStackTrace();


        }
    }




    public void addToEnrolledInECs(Team.TaskTeam ec) {

        this.getParticipatingInECs().add(ec);
    }




}
