package smart.things;

import smart.Capability.SenseAndReportTemparature;
import smart.Capability.SenseLightLevel;
import util.Settings;

public class LightSensor extends Thing {

    public LightSensor(String n, String location) throws Exception {
        super(n, location, true, true, "*");
//        ThingManager tm = ThingManager.getInstance();
//        tm.addConnectivityBelief(n, Settings.CONNECTED);
//        tm.addOperationalBelief(n, Settings.ON);
//        tm.addLocationBelief(n, location);
        addThingCapability(new SenseLightLevel(), Settings.DETECT_LIGHT_LEVEL, "*", null);
    }

    public LightSensor(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel, int max) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
//        ThingManager tm = ThingManager.getInstance();
//        tm.addConnectivityBelief(name, Settings.CONNECTED);
//        tm.addOperationalBelief(name, Settings.ON);
//        tm.addLocationBelief(name, location);
        addThingCapability(new SenseLightLevel(), Settings.DETECT_LIGHT_LEVEL, "*", null);


    }
}
