package smart.things;

import smart.Capability.AnalyzeEvent;
import util.Settings;

public class PoliceServer extends Thing {

    public PoliceServer(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new AnalyzeEvent(), Settings.ANALYZE_INCIDENT, "*", null);


    }

    public PoliceServer(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new AnalyzeEvent(), Settings.ANALYZE_INCIDENT,"*", null);


    }
}