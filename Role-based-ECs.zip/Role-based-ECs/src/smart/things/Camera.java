package smart.things;


import smart.Capability.CountBoats;
import smart.Capability.CountPeople;
import smart.Capability.StreamLiveInfo;
import util.Settings;

import java.util.HashSet;

public class Camera extends Thing {

    public Camera(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        HashSet<String> confCap = new HashSet<String>();
        confCap.add(Settings.STREAM_BOATS_COUNT);
        confCap.add(Settings.STREAM_PEOPLE_COUNT);
        HashSet<String> confCap2 = new HashSet<String>();
        confCap2.add(Settings.PROVIDE_INFO);
        addThingCapability(new CountBoats(), Settings.STREAM_BOATS_COUNT, "*", confCap2);
        addThingCapability(new CountPeople(), Settings.STREAM_PEOPLE_COUNT, "*", confCap2);
        addThingCapability(new StreamLiveInfo(), Settings.PROVIDE_INFO, "*", confCap);

    }

    public Camera(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        HashSet<String> confCap = new HashSet<String>();
        confCap.add(Settings.STREAM_BOATS_COUNT);
        confCap.add(Settings.STREAM_PEOPLE_COUNT);
        HashSet<String> confCap2 = new HashSet<String>();
        confCap2.add(Settings.PROVIDE_INFO);
        addThingCapability(new CountBoats(), Settings.STREAM_BOATS_COUNT, "*", confCap2);
        addThingCapability(new CountPeople(), Settings.STREAM_PEOPLE_COUNT, "*", confCap2);
        addThingCapability(new StreamLiveInfo(), Settings.PROVIDE_INFO, "*", confCap);

    }
}