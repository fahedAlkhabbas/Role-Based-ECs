package smart.things;


import smart.Capability.CountPeople;
import smart.Capability.PublishDiscounts;
import util.Settings;

public class Beacon extends Thing {

    public Beacon(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new PublishDiscounts(), Settings.PUBLISH_DISCOUNTS, "*", null);


    }

    public Beacon(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new PublishDiscounts(), Settings.PUBLISH_DISCOUNTS, "*", null);
    }
}