package smart.things;

import smart.Capability.DisplayStream;
import util.Settings;

public class SmartScreen extends Thing {


    public SmartScreen(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new DisplayStream(), Settings.DISPLAY_STREAM, "1", null);


    }

    public SmartScreen(String n, String location) throws Exception {
        super(n, location,  true, true, "*");
        addThingCapability(new DisplayStream(), Settings.DISPLAY_STREAM, "1", null);
    }
}
