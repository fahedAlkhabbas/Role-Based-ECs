package smart.things;

import smart.Capability.PublishDiscounts;
import smart.Capability.StreamLiveInfo;
import util.Settings;

public class SoundSensor extends Thing {

    public SoundSensor(String n, String location) throws Exception {
        super(n, location, true, true, "*");
        addThingCapability(new StreamLiveInfo(), Settings.PROVIDE_INFO, "*", null);


    }

    public SoundSensor(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new StreamLiveInfo(), Settings.PROVIDE_INFO, "*", null);


    }
}