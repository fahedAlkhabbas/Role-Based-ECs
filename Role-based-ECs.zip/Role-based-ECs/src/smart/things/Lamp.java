package smart.things;

import smart.Capability.ControlLight;
import util.Settings;

public class Lamp extends Thing {

    public Lamp(String n, String location) throws Exception {
        super(n, location, true, true, "*");
          addThingCapability(new ControlLight(), Settings.CONTROL_LIGHT_LEVEL, "*", null);


    }

    public Lamp(String name, String location, boolean reliesOnBatteries, boolean operationSatus, boolean connectivityStatus, String bLevel) throws Exception {
        super(name, location, operationSatus, connectivityStatus, bLevel);
        addThingCapability(new ControlLight(), Settings.CONTROL_LIGHT_LEVEL, "*", null);


    }
}
