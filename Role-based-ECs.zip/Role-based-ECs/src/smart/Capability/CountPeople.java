package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import util.Settings;

public class CountPeople extends Capability {
    public static String cap_name = Settings.STREAM_PEOPLE_COUNT;
    public CountPeople() {
        addGoal(new Plan(cap_name) {
            public Goal.States execute(Data d) {
               System.out.println(d.getValue(Settings.PEOPLE_COUNTER) + "counts people ");
                return States.PASSED;
            }
        });
    }
}
