package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import util.Settings;

public class PublishDiscounts extends Capability {
    public static String cap_name = Settings.PUBLISH_DISCOUNTS;
    public PublishDiscounts() {
        addGoal(new Plan(cap_name) {
            public Goal.States execute(Data d) {
                 System.out.println(d.getValue(Settings.DISCOUNTS_PUBLISHER) +" publishes discounts");
                return States.PASSED;
            }
        });
    }
}
