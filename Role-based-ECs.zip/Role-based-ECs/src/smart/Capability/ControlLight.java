package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Plan;
import util.Settings;

public class ControlLight extends Capability {
    public static String cap_name = Settings.CONTROL_LIGHT_LEVEL;
    public ControlLight() {
        addGoal(new Plan(cap_name) {
            public States execute(Data d) {
                  System.out.println(d.getValue(Settings.LIGHT_LEVEL_CONTROLLER)+ " controls the light level.");
                  return States.PASSED;
            }
        });
    }
}