package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import util.Settings;

public class StreamLiveInfo extends Capability {
    public static String cap_name = Settings.PROVIDE_INFO;
    public StreamLiveInfo() {
        addGoal(new Plan(Settings.PROVIDE_INFO) {
            public Goal.States execute(Data d) {
                System.out.println("The " +d.getValue(Settings.INCIDENT_INFO_PROVIDER) + "  provides data about incident");
                return States.PASSED;
            }
        });
    }
}
