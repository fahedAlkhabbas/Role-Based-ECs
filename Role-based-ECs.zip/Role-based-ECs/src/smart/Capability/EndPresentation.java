package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import com.intendico.gorite.addon.TimeTrigger;
import util.Settings;

public class EndPresentation extends Capability {
    public static String cap_name =Settings.END_PRESENTATION;
    public EndPresentation() {
        addGoal(new Plan(cap_name) {
                    public Goal.States execute(Data d) {
                        if (TimeTrigger.isPending(d, "deadline", 10)) {
                            System.err.println("Presentation is ongoing...");
                            return Goal.States.BLOCKED;
                        }
                        System.err.printf("Presentation has ended");
                        int requestId = (int) d.getValue(Settings.REQUEST_ID);
                    //    ecm.setECStatusCompleted(requestId);
                        return Goal.States.PASSED;
                    }
                }
       );
    }
}

