package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Plan;
import util.Settings;

public class StreamPresentation extends Capability {
    public static String cap_name = Settings.STREAM_PRESENTATION;
    public StreamPresentation() {
        addGoal(new Plan(cap_name) {
            public States execute(Data d) {
                 System.out.println(d.getValue(Settings.PRESENTER) + " Streams presentation");
                return States.PASSED;
            }
        });
    }
}
