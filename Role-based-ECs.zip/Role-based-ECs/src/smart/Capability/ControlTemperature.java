package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Plan;
import util.Settings;

public class ControlTemperature extends Capability {
    public static String cap_name = Settings.CONTROL_TِEMPERATURE;
    public ControlTemperature() {
        addGoal(new Plan(cap_name) {
            public States execute(Data d) {
              System.out.println(d.getValue(Settings.TEMPERATURE_ACTUATOR) +"  actuates temperature" );
                return States.PASSED;
            }
        });
    }
}
