package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import util.Settings;

public class CountBoats extends Capability {
    public static String cap_name = Settings.STREAM_BOATS_COUNT;
    public CountBoats() {
        addGoal(new Plan(cap_name) {
            public Goal.States execute(Data d) {
              System.out.println(d.getValue(Settings.BOATS_COUNTER) +" counts people");
                return States.PASSED;
            }
        });
    }
}
