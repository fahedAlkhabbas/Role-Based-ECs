package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Goal;
import com.intendico.gorite.Plan;
import util.Settings;

public class DisplayStream extends Capability {
    public static String cap_name = Settings.DISPLAY_STREAM;
    public DisplayStream() {
        addGoal(new Plan(cap_name) {
            public Goal.States execute(Data d) {
                 System.out.println(d.getValue(Settings.VIEWER)+ " displays stream");
                return States.PASSED;
            }
        });
    }
}
