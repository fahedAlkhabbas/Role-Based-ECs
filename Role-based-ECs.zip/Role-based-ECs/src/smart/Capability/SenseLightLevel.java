package smart.Capability;

import com.intendico.gorite.Capability;
import com.intendico.gorite.Data;
import com.intendico.gorite.Plan;
import util.Settings;

public class SenseLightLevel extends Capability {
    public static String cap_name = Settings.DETECT_LIGHT_LEVEL;
    public SenseLightLevel() {
        addGoal(new Plan(cap_name) {
            public States execute(Data d) {
              //  System.out.println("The sensor "+ d.getValue(Settings.LIGHT_LEVEL_DETECTOR) + "is measuring the light level000000======== " + "request Id = " + d.getValue(Settings.REQUEST_ID));
                return States.PASSED;
            }
        });
    }
}
