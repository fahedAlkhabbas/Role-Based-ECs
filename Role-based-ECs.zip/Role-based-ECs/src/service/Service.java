package service;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import java.util.ArrayList;
import java.util.Arrays;

public class Service {


    public String forecastTemperature(ArrayList data) {

        String forecastedTemp = null;
        try {

            Client client = Client.create();
            String url = "http://127.0.0.1:5000/ml";
            WebResource webResource = client
                    .resource(url);
            // this raw is added as an example.
            String x ="[-0.4615684580691577,1.0218734234750557,0.6928145399586992,1.6687344223792435,-1.0188258669967425,-0.02720932638885662,1.8499337835299576,0.4702283448962636,-0.11802221723108648,-0.1182455722159597]";
            ClientResponse response = webResource.accept("application/json").type("application/json")
                    .post(ClientResponse.class, x);

            if (response.getStatus() != 200) {

                throw new RuntimeException("Failed : HTTP error code : "
                        + response.getStatus());
            }

            String ot = response.getEntity(String.class);
            forecastedTemp = ot.replace("\"", "");


        } catch (Exception e) {

            e.printStackTrace();

        }

        return null;


    }
}
