package ec.bootstraping;

import ec.core.agent.AgentsManager;
import ec.agents.applicationAgent.*;
import ec.agents.objects.Entity;
import smart.things.*;

import java.util.ArrayList;

public class Initializer {

    public ArrayList<Entity> entities = new ArrayList<>();

    public static void startECM() {
//        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
//        Thread thread = new Thread(ecm);
//        thread.start();
//        Executor ecmExecutor = new Executor("ECM");
//        ecmExecutor.addPerformer(ecm);
//        ecmExecutor.start();

    }

    public void initializeAgentManager(int expNumber, int numberOfEntities, int numberOfCompanies) throws Exception {
        AgentsManager agentsManager = AgentsManager.getInstance();

        if (expNumber == 1) {

            LightAgent LAgent = new LightAgent("LA1");
            ArrayList agents = new ArrayList();
            agents.add(LAgent);
            DisplayManagementAgent DMA = new DisplayManagementAgent("DMA");
            agents.add(DMA);

            LightSensor ls = new LightSensor("LS1", "room1");
            LAgent.addAvailableThing(ls);
            Lamp lp = new Lamp("LP1", "room1");
            LAgent.addAvailableThing(lp);
            LightSensor ls2 = new LightSensor("LS2", "room1");
            LAgent.addAvailableThing(ls2);
            Lamp lp2 = new Lamp("LP2", "room1");
            LAgent.addAvailableThing(lp2);

            SmartScreen sc = new SmartScreen("SC1", "room1");
            Laptop lt1 = new Laptop("lt1", "room1");
            SmartScreen sc2 = new SmartScreen("SC2", "room1");
            Laptop lt2 = new Laptop("lt2", "room1");
            DMA.addAvailableThing(sc);
            DMA.addAvailableThing(sc2);
            DMA.addAvailableThing(lt1);
            DMA.addAvailableThing(lt2);


            LightSensor ls3 = new LightSensor("LS3", "room2");
            LAgent.addAvailableThing(ls3);
            Lamp lp3 = new Lamp("LP3", "room2");
            LAgent.addAvailableThing(lp3);
            LightSensor ls4 = new LightSensor("LS4", "room2");
            LAgent.addAvailableThing(ls4);
            Lamp lp4 = new Lamp("LP4", "room2");
            LAgent.addAvailableThing(lp4);

            SmartScreen sc3 = new SmartScreen("SC3", "room2");
            Laptop lt3 = new Laptop("lt3", "room2");
            SmartScreen sc4 = new SmartScreen("SC4", "room2");
            Laptop lt4 = new Laptop("lt4", "room2");
            DMA.addAvailableThing(sc3);
            DMA.addAvailableThing(sc4);
            DMA.addAvailableThing(lt3);
            DMA.addAvailableThing(lt4);


            LightSensor ls5 = new LightSensor("LS5", "room3");
            LAgent.addAvailableThing(ls5);
            Lamp lp5 = new Lamp("LP5", "room3");
            LAgent.addAvailableThing(lp5);
            LightSensor ls6 = new LightSensor("LS6", "room3");
            LAgent.addAvailableThing(ls6);
            Lamp lp6 = new Lamp("LP6", "room3");
            LAgent.addAvailableThing(lp6);

            SmartScreen sc5 = new SmartScreen("SC5", "room3");
            Laptop lt5 = new Laptop("lt5", "room3");
            SmartScreen sc6 = new SmartScreen("SC6", "room3");
            Laptop lt6 = new Laptop("lt6", "room3");
            DMA.addAvailableThing(sc5);
            DMA.addAvailableThing(sc6);
            DMA.addAvailableThing(lt5);
            DMA.addAvailableThing(lt6);


            LightSensor ls7 = new LightSensor("LS7", "room4");
            LAgent.addAvailableThing(ls7);
            Lamp lp7 = new Lamp("LP7", "room4");
            LAgent.addAvailableThing(lp7);
            LightSensor ls8 = new LightSensor("LS8", "room4");
            LAgent.addAvailableThing(ls8);
            Lamp lp8 = new Lamp("LP8", "room4");
            LAgent.addAvailableThing(lp8);

            SmartScreen sc7 = new SmartScreen("SC7", "room4");
            Laptop lt7 = new Laptop("lt7", "room4");
            SmartScreen sc8 = new SmartScreen("SC8", "room4");
            Laptop lt8 = new Laptop("lt8", "room4");
            DMA.addAvailableThing(sc7);
            DMA.addAvailableThing(sc7);
            DMA.addAvailableThing(lt8);
            DMA.addAvailableThing(lt8);


            LightSensor ls9 = new LightSensor("LS9", "room5");
            LAgent.addAvailableThing(ls9);
            Lamp lp9 = new Lamp("LP9", "room5");
            LAgent.addAvailableThing(lp9);
            LightSensor ls10 = new LightSensor("LS10", "room5");
            LAgent.addAvailableThing(ls10);
            Lamp lp10 = new Lamp("LP10", "room5");
            LAgent.addAvailableThing(lp10);

            SmartScreen sc9 = new SmartScreen("SC9", "room5");
            Laptop lt9 = new Laptop("lt9", "room5");
            SmartScreen sc10 = new SmartScreen("SC10", "room5");
            Laptop lt10 = new Laptop("lt10", "room5");
            DMA.addAvailableThing(sc9);
            DMA.addAvailableThing(sc10);
            DMA.addAvailableThing(lt9);
            DMA.addAvailableThing(lt10);


            LightSensor ls11 = new LightSensor("LS11", "room6");
            LAgent.addAvailableThing(ls11);
            Lamp lp11 = new Lamp("LP11", "room6");
            LAgent.addAvailableThing(lp11);
            LightSensor ls12 = new LightSensor("LS12", "room6");
            LAgent.addAvailableThing(ls12);
            Lamp lp12 = new Lamp("LP12", "room6");
            LAgent.addAvailableThing(lp12);

            SmartScreen sc11 = new SmartScreen("SC11", "room6");
            Laptop lt11 = new Laptop("lt11", "room6");
            SmartScreen sc12 = new SmartScreen("SC12", "room6");
            Laptop lt12 = new Laptop("lt12", "room6");
            DMA.addAvailableThing(sc11);
            DMA.addAvailableThing(sc12);
            DMA.addAvailableThing(lt11);
            DMA.addAvailableThing(lt12);


            LightSensor ls13 = new LightSensor("LS13", "room7");
            LAgent.addAvailableThing(ls13);
            Lamp lp13 = new Lamp("LP13", "room7");
            LAgent.addAvailableThing(lp13);
            LightSensor ls14 = new LightSensor("LS14", "room7");
            LAgent.addAvailableThing(ls14);
            Lamp lp14 = new Lamp("LP14", "room7");
            LAgent.addAvailableThing(lp14);

            SmartScreen sc13 = new SmartScreen("SC13", "room7");
            Laptop lt13 = new Laptop("lt13", "room7");
            SmartScreen sc14 = new SmartScreen("SC14", "room7");
            Laptop lt14 = new Laptop("lt14", "room7");
            DMA.addAvailableThing(sc13);
            DMA.addAvailableThing(sc14);
            DMA.addAvailableThing(lt13);
            DMA.addAvailableThing(lt14);


            LightSensor ls15 = new LightSensor("LS15", "room8");
            LAgent.addAvailableThing(ls15);
            Lamp lp15 = new Lamp("LP15", "room8");
            LAgent.addAvailableThing(lp15);
            LightSensor ls16 = new LightSensor("LS16", "room8");
            LAgent.addAvailableThing(ls16);
            Lamp lp16 = new Lamp("LP16", "room8");
            LAgent.addAvailableThing(lp16);

            SmartScreen sc15 = new SmartScreen("SC15", "room8");
            Laptop lt15 = new Laptop("lt15", "room8");
            SmartScreen sc16 = new SmartScreen("SC16", "room8");
            Laptop lt16 = new Laptop("lt16", "room8");
            DMA.addAvailableThing(sc15);
            DMA.addAvailableThing(sc16);
            DMA.addAvailableThing(lt15);
            DMA.addAvailableThing(lt16);


            LightSensor ls17 = new LightSensor("LS17", "room9");
            LAgent.addAvailableThing(ls17);
            Lamp lp17 = new Lamp("LP17", "room9");
            LAgent.addAvailableThing(lp17);
            LightSensor ls18 = new LightSensor("LS18", "room9");
            LAgent.addAvailableThing(ls18);
            Lamp lp18 = new Lamp("LP18", "room9");
            LAgent.addAvailableThing(lp18);

            SmartScreen sc17 = new SmartScreen("SC17", "room9");
            Laptop lt17 = new Laptop("lt17", "room9");
            SmartScreen sc18 = new SmartScreen("SC18", "room9");
            Laptop lt18 = new Laptop("lt18", "room9");
            DMA.addAvailableThing(sc17);
            DMA.addAvailableThing(sc18);
            DMA.addAvailableThing(lt17);
            DMA.addAvailableThing(lt18);


            LightSensor ls19 = new LightSensor("LS19", "room10");
            LAgent.addAvailableThing(ls19);
            Lamp lp19 = new Lamp("LP19", "room10");
            LAgent.addAvailableThing(lp19);
            LightSensor ls20 = new LightSensor("LS20", "room10");
            LAgent.addAvailableThing(ls20);
            Lamp lp20 = new Lamp("LP20", "room10");
            LAgent.addAvailableThing(lp20);

            SmartScreen sc19 = new SmartScreen("SC19", "room10");
            Laptop lt19 = new Laptop("lt19", "room10");
            SmartScreen sc20 = new SmartScreen("SC20", "room10");
            Laptop lt20 = new Laptop("lt20", "room10");
            DMA.addAvailableThing(sc19);
            DMA.addAvailableThing(sc20);
            DMA.addAvailableThing(lt19);
            DMA.addAvailableThing(lt20);


            LightSensor ls21 = new LightSensor("LS21", "room11");
            LAgent.addAvailableThing(ls21);
            Lamp lp21 = new Lamp("LP21", "room11");
            LAgent.addAvailableThing(lp21);
            LightSensor ls22 = new LightSensor("LS22", "room11");
            LAgent.addAvailableThing(ls22);
            Lamp lp22 = new Lamp("LP22", "room11");
            LAgent.addAvailableThing(lp22);

            SmartScreen sc21 = new SmartScreen("SC21", "room11");
            Laptop lt21 = new Laptop("lt21", "room11");
            SmartScreen sc22 = new SmartScreen("SC22", "room11");
            Laptop lt22 = new Laptop("lt22", "room11");
            DMA.addAvailableThing(sc21);
            DMA.addAvailableThing(sc22);
            DMA.addAvailableThing(lt21);
            DMA.addAvailableThing(lt22);


            LightSensor ls23 = new LightSensor("LS23", "room12");
            LAgent.addAvailableThing(ls23);
            Lamp lp23 = new Lamp("LP23", "room12");
            LAgent.addAvailableThing(lp23);
            LightSensor ls24 = new LightSensor("LS24", "room12");
            LAgent.addAvailableThing(ls24);
            Lamp lp24 = new Lamp("LP24", "room12");
            LAgent.addAvailableThing(lp24);

            SmartScreen sc23 = new SmartScreen("SC23", "room12");
            Laptop lt23 = new Laptop("lt23", "room12");
            SmartScreen sc24 = new SmartScreen("SC24", "room12");
            Laptop lt24 = new Laptop("lt24", "room12");
            DMA.addAvailableThing(sc23);
            DMA.addAvailableThing(sc24);
            DMA.addAvailableThing(lt23);
            DMA.addAvailableThing(lt24);


            LightSensor ls25 = new LightSensor("LS25", "room13");
            LAgent.addAvailableThing(ls25);
            Lamp lp25 = new Lamp("LP25", "room13");
            LAgent.addAvailableThing(lp25);
            LightSensor ls26 = new LightSensor("LS26", "room13");
            LAgent.addAvailableThing(ls26);
            Lamp lp26 = new Lamp("LP26", "room13");
            LAgent.addAvailableThing(lp26);

            SmartScreen sc25 = new SmartScreen("SC25", "room13");
            Laptop lt25 = new Laptop("lt25", "room13");
            SmartScreen sc26 = new SmartScreen("SC26", "room13");
            Laptop lt26 = new Laptop("lt26", "room13");
            DMA.addAvailableThing(sc25);
            DMA.addAvailableThing(sc26);
            DMA.addAvailableThing(lt25);
            DMA.addAvailableThing(lt26);


            LightSensor ls27 = new LightSensor("LS27", "room14");
            LAgent.addAvailableThing(ls27);
            Lamp lp27 = new Lamp("LP27", "room14");
            LAgent.addAvailableThing(lp27);
            LightSensor ls28 = new LightSensor("LS28", "room14");
            LAgent.addAvailableThing(ls28);
            Lamp lp28 = new Lamp("LP28", "room14");
            LAgent.addAvailableThing(lp28);

            SmartScreen sc27 = new SmartScreen("SC27", "room14");
            Laptop lt27 = new Laptop("lt27", "room14");
            SmartScreen sc28 = new SmartScreen("SC28", "room14");
            Laptop lt28 = new Laptop("lt28", "room14");
            DMA.addAvailableThing(sc27);
            DMA.addAvailableThing(sc28);
            DMA.addAvailableThing(lt27);
            DMA.addAvailableThing(lt28);


            LightSensor ls29 = new LightSensor("LS29", "room15");
            LAgent.addAvailableThing(ls29);
            Lamp lp29 = new Lamp("LP29", "room15");
            LAgent.addAvailableThing(lp29);
            LightSensor ls30 = new LightSensor("LS30", "room15");
            LAgent.addAvailableThing(ls30);
            Lamp lp30 = new Lamp("LP30", "room15");
            LAgent.addAvailableThing(lp30);

            SmartScreen sc29 = new SmartScreen("SC29", "room15");
            Laptop lt29 = new Laptop("lt29", "room15");
            SmartScreen sc30 = new SmartScreen("SC30", "room15");
            Laptop lt30 = new Laptop("lt30", "room15");
            DMA.addAvailableThing(sc29);
            DMA.addAvailableThing(sc30);
            DMA.addAvailableThing(lt29);
            DMA.addAvailableThing(lt30);


            LightSensor ls31 = new LightSensor("LS31", "room16");
            LAgent.addAvailableThing(ls31);
            Lamp lp31 = new Lamp("LP31", "room16");
            LAgent.addAvailableThing(lp31);
            LightSensor ls32 = new LightSensor("LS32", "room16");
            LAgent.addAvailableThing(ls32);
            Lamp lp32 = new Lamp("LP32", "room16");
            LAgent.addAvailableThing(lp32);

            SmartScreen sc31 = new SmartScreen("SC31", "room16");
            Laptop lt31 = new Laptop("lt31", "room16");
            SmartScreen sc32 = new SmartScreen("SC32", "room16");
            Laptop lt32 = new Laptop("lt32", "room16");
            DMA.addAvailableThing(sc31);
            DMA.addAvailableThing(sc32);
            DMA.addAvailableThing(lt31);
            DMA.addAvailableThing(lt32);


            LightSensor ls33 = new LightSensor("LS33", "room17");
            LAgent.addAvailableThing(ls33);
            Lamp lp33 = new Lamp("LP33", "room17");
            LAgent.addAvailableThing(lp33);
            LightSensor ls34 = new LightSensor("LS34", "room17");
            LAgent.addAvailableThing(ls34);
            Lamp lp34 = new Lamp("LP34", "room17");
            LAgent.addAvailableThing(lp34);

            SmartScreen sc33 = new SmartScreen("SC33", "room17");
            Laptop lt33 = new Laptop("lt33", "room17");
            SmartScreen sc34 = new SmartScreen("SC34", "room17");
            Laptop lt34 = new Laptop("lt34", "room17");
            DMA.addAvailableThing(sc33);
            DMA.addAvailableThing(sc34);
            DMA.addAvailableThing(lt33);
            DMA.addAvailableThing(lt34);


            LightSensor ls35 = new LightSensor("LS35", "room18");
            LAgent.addAvailableThing(ls35);
            Lamp lp35 = new Lamp("LP35", "room18");
            LAgent.addAvailableThing(lp35);
            LightSensor ls36 = new LightSensor("LS36", "room18");
            LAgent.addAvailableThing(ls36);
            Lamp lp38 = new Lamp("LP38", "room18");
            LAgent.addAvailableThing(lp38);

            SmartScreen sc35 = new SmartScreen("SC33", "room18");
            Laptop lt35 = new Laptop("lt35", "room18");
            SmartScreen sc36 = new SmartScreen("SC36", "room18");
            Laptop lt36 = new Laptop("lt36", "room18");
            DMA.addAvailableThing(sc35);
            DMA.addAvailableThing(sc36);
            DMA.addAvailableThing(lt35);
            DMA.addAvailableThing(lt36);


            LightSensor ls37 = new LightSensor("LS37", "room19");
            LAgent.addAvailableThing(ls37);
            Lamp lp37 = new Lamp("LP37", "room19");
            LAgent.addAvailableThing(lp37);
            LightSensor ls38 = new LightSensor("LS38", "room19");
            LAgent.addAvailableThing(ls38);
            Lamp lp40 = new Lamp("LP40", "room19");
            LAgent.addAvailableThing(lp40);

            SmartScreen sc37 = new SmartScreen("SC37", "room19");
            Laptop lt37 = new Laptop("lt37", "room19");
            SmartScreen sc38 = new SmartScreen("SC38", "room19");
            Laptop lt38 = new Laptop("lt38", "room19");
            DMA.addAvailableThing(sc37);
            DMA.addAvailableThing(sc38);
            DMA.addAvailableThing(lt37);
            DMA.addAvailableThing(lt38);


            LightSensor ls39 = new LightSensor("LS39", "room20");
            LAgent.addAvailableThing(ls39);
            Lamp lp39 = new Lamp("LP39", "room20");
            LAgent.addAvailableThing(lp39);
            LightSensor ls40 = new LightSensor("LS40", "room20");
            LAgent.addAvailableThing(ls40);
            Lamp lp42 = new Lamp("LP42", "room20");
            LAgent.addAvailableThing(lp42);

            SmartScreen sc39 = new SmartScreen("SC39", "room20");
            Laptop lt39 = new Laptop("lt39", "room20");
            SmartScreen sc40 = new SmartScreen("SC40", "room20");
            Laptop lt40 = new Laptop("lt40", "room20");
            DMA.addAvailableThing(sc39);
            DMA.addAvailableThing(sc40);
            DMA.addAvailableThing(lt39);
            DMA.addAvailableThing(lt40);

            agentsManager.addAgents("room1", agents);
            agentsManager.addAgents("room2", agents);
            agentsManager.addAgents("room3", agents);
            agentsManager.addAgents("room4", agents);
            agentsManager.addAgents("room5", agents);
            agentsManager.addAgents("room6", agents);
            agentsManager.addAgents("room7", agents);
            agentsManager.addAgents("room8", agents);
            agentsManager.addAgents("room9", agents);
            agentsManager.addAgents("room10", agents);
            agentsManager.addAgents("room11", agents);
            agentsManager.addAgents("room12", agents);
            agentsManager.addAgents("room13", agents);
            agentsManager.addAgents("room14", agents);
            agentsManager.addAgents("room15", agents);
            agentsManager.addAgents("room16", agents);
            agentsManager.addAgents("room17", agents);
            agentsManager.addAgents("room18", agents);
            agentsManager.addAgents("room19", agents);
            agentsManager.addAgents("room20", agents);


        } else if (expNumber == 2) {
            CityInfrastructureAgent cityInfrastructureAgent = new CityInfrastructureAgent("CIA");
            TempSensor tempSensor = new TempSensor("TempSensor", "*");
            Camera camera = new Camera("Camera", "*"); // to be replaced with harbor.
            SoundSensor soundSensor = new SoundSensor("SoundSensor", "*");
            cityInfrastructureAgent.addAvailableThing(tempSensor);
            cityInfrastructureAgent.addAvailableThing(camera);
            cityInfrastructureAgent.addAvailableThing(soundSensor);

            ServiceCompanyAgent serviceCompanyAgent = new ServiceCompanyAgent("SCA");
            Server server = new Server("companyServer", "*");
            serviceCompanyAgent.addAvailableThing(server);

            PoliceAgent policeAgent = new PoliceAgent("PA");
            PoliceServer policeServer = new PoliceServer("policeServer", "*");
            policeAgent.addAvailableThing(policeServer);

            for (int i = 0; i < numberOfEntities; i++) {
                String location = "location" + i;
                Entity e = new Entity(i, 15, location);
                entities.add(e);
                ArrayList<ApplicationLevelAgent> agents = new ArrayList<ApplicationLevelAgent>();
                agents.add(serviceCompanyAgent);
                agents.add(cityInfrastructureAgent);
                agents.add(policeAgent);
                agentsManager.addAgents(location, agents);
            }

        } else if (expNumber == 3) {
            CityInfrastructureAgent cityInfrastructureAgent = new CityInfrastructureAgent("CIA");
            TempSensor tempSensor = new TempSensor("TempSensor", "*");
            Camera camera = new Camera("Camera", "*"); // to be replaced with harbor.
            SoundSensor soundSensor = new SoundSensor("SoundSensor", "*");
            cityInfrastructureAgent.addAvailableThing(tempSensor);
            cityInfrastructureAgent.addAvailableThing(camera);
            cityInfrastructureAgent.addAvailableThing(soundSensor);
            ArrayList<ApplicationLevelAgent> agents = new ArrayList<ApplicationLevelAgent>();
            for (int i = 0; i < numberOfCompanies; i++) {
                ServiceCompanyAgent serviceCompanyAgent = new ServiceCompanyAgent("SCA" + i);
                Server server = new Server("companyServer" + i, "*");
                serviceCompanyAgent.addAvailableThing(server);
                agents.add(serviceCompanyAgent);
            }


            agents.add(cityInfrastructureAgent);
            for (int i = 0; i < numberOfEntities; i++) {
                String location = "location" + i;
                Entity e = new Entity(i, 15, location);
                entities.add(e);

                agentsManager.addAgents(location, agents);
            }

        } else if (expNumber == 4) {

            TemperatureAgent temperatureAgent = new TemperatureAgent("tempAgent");
            TempSensor tempSensor = new TempSensor("TempSensor", "room1");
            Conditioner conditioner1 = new Conditioner("Conditioner1", "room1");
            Conditioner conditioner2 = new Conditioner("Conditioner2", "room1");
            temperatureAgent.addAvailableThing(tempSensor);
            temperatureAgent.addAvailableThing(conditioner1);
            temperatureAgent.addAvailableThing(conditioner2);
            agentsManager.addAgent("room1", temperatureAgent);


        }

        else if (expNumber == 5){
            LightAgent LAgent = new LightAgent("LA1");
            ArrayList agents = new ArrayList();
            agents.add(LAgent);
            DisplayManagementAgent DMA = new DisplayManagementAgent("DMA");
            agents.add(DMA);

            LightSensor ls = new LightSensor("LS1", "room1");
            LAgent.addAvailableThing(ls);
            Lamp lp = new Lamp("LP1", "room1");
            LAgent.addAvailableThing(lp);
            LightSensor ls2 = new LightSensor("LS2", "room1");
            LAgent.addAvailableThing(ls2);
            Lamp lp2 = new Lamp("LP2", "room1");
            LAgent.addAvailableThing(lp2);

            SmartScreen sc = new SmartScreen("SC1", "room1");
            Laptop lt1 = new Laptop("lt1", "room1");
            SmartScreen sc2 = new SmartScreen("SC2", "room1");
            Laptop lt2 = new Laptop("lt2", "room1");
            DMA.addAvailableThing(sc);
            DMA.addAvailableThing(sc2);
            DMA.addAvailableThing(lt1);
            DMA.addAvailableThing(lt2);

            agentsManager.addAgents("room1", agents);


        }


    }

    public ArrayList<Entity> getEntities() {
        return entities;

    }
}
