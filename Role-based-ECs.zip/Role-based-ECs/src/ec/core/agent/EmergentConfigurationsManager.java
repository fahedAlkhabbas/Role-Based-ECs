package ec.core.agent;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.objects.ECInfoObject;
import ec.agents.schema.*;

import smart.things.Thing;
import util.Settings;
import util.TeamComparator;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class EmergentConfigurationsManager extends Performer implements Runnable {
    public static int request_id_generator = 0;
    static LinkedHashSet<Team> activeECs = new LinkedHashSet<Team>();
    static HashMap<String, Integer> rolesPriorities = new HashMap<String, Integer>();
    static ConcurrentHashMap<Integer, ECInfoObject> teamPerformers = new ConcurrentHashMap<Integer, ECInfoObject>();
    static ConcurrentHashMap<Integer, Executor> teamExecutors = new ConcurrentHashMap<Integer, Executor>();
    static ConcurrentHashMap<Integer, String> teamStatus = new ConcurrentHashMap<Integer, String>();

    private static EmergentConfigurationsManager ecm = null;
    HashMap<String, HashSet<String>> goalsDecomposition = new HashMap<String, HashSet<String>>();
    HashSet<String> singletonGoals = new HashSet<String>();
    ConcurrentHashMap<Integer, Team> activeECsRequests = new ConcurrentHashMap<Integer, Team>();
    AgentsManager agentsManager;


    PriorityQueue<AbstractMap.SimpleEntry<Integer, Team>> priorityQueue = new
            PriorityQueue<AbstractMap.SimpleEntry<Integer, Team>>(11, new TeamComparator());


    private EmergentConfigurationsManager() {

    }

    private EmergentConfigurationsManager(String n) throws Exception {
        super(n);
        initializeGoals();
        rolesPriorities.put(Settings.GUEST, 2);
        rolesPriorities.put(Settings.ADVERTISEMENT_REQUESTER, 3);
        rolesPriorities.put(Settings.SPEAKER, 3);
        rolesPriorities.put(Settings.JANITOR, 4);
        rolesPriorities.put(Settings.AUTHORITY, 5);

    }

    public synchronized static int getRequest_id_generator() {
        return ++request_id_generator;
    }

    public static void setRequest_id_generator(int request_id_generator) {
        EmergentConfigurationsManager.request_id_generator = request_id_generator;
    }

    public static LinkedHashSet<Team> getActiveECs() {
        return activeECs;
    }

    public static EmergentConfigurationsManager getInstance() {
        if (ecm == null) {
            try {
                ecm = new EmergentConfigurationsManager("ECM");
            } catch (Exception e) {
                e.printStackTrace();
            }

        }

        return ecm;

    }

    public String getRequestGoalName(int requestId) {

        return teamPerformers.get(requestId).getGoalName();
    }

    public String getRequestLocation(int requestId) {

        return teamPerformers.get(requestId).getLocation();
    }

    private void initializeGoals() {
        singletonGoals.add(Settings.ADJUST_LIGHT_LEVEL);
        HashSet<String> subgoals = new HashSet<String>();
        subgoals.add(Settings.ADJUST_LIGHT_LEVEL);
        subgoals.add(Settings.CONFIGURE_DISPLAY_MEDIA);
        goalsDecomposition.put(Settings.GIVE_PRESENTATION, subgoals);
    }

    public void createUsers(int number) {
        for (int i = 0; i < number; i++) {
            rolesPriorities.put("role" + i, 3);
        }

    }


    public void run() {

        while (true) {

            try {
                enactECs();
                Thread.sleep(50);
            } catch (Exception e) {
                e.printStackTrace();
            }


        }

    }


    private void enactECs() {

        if (priorityQueue.size() > 0) {
            try {
                AbstractMap.SimpleEntry<Integer, Team> ec = priorityQueue.poll();
                int requestId = ec.getKey();
                ECInfoObject ECInfoObject = teamPerformers.get(requestId);
                formAndEnact(ECInfoObject);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    public void formAndEnact(ECInfoObject ECInfoObject) throws Exception {
        switch (ECInfoObject.getSchemaName()) {
            case Settings.GIVE_PRESENTATION_ABSTRACT_SCHEMA:
                givePresentation(ECInfoObject.getLocation(), ECInfoObject.getRole());
                break;
            case Settings.ADVERTISE_BOAT_ADS_ABSTRACT_SCHEMA:
                advertiseBoatAds(ECInfoObject.getRole(), ECInfoObject.getLocation());
                break;

            case Settings.ADVERTISE_MUSEUM_ADS_ABSTRACT_SCHEMA:
                advertiseMuseum(ECInfoObject.getRole(), ECInfoObject.getLocation());
                break;
            case Settings.MANAGE_INCIDENT_ABSTRACT_SCHEMA:
                AnalyzeIncident(ECInfoObject.getLocation(), ECInfoObject.getRole());
                break;

        }


    }

    public void adjustLight(String role, String location, int desiredLightLevel) throws Exception {
        String goalName = Settings.ADJUST_LIGHT_LEVEL;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        AdjustLightLevelAbstractSchema ec = new AdjustLightLevelAbstractSchema(role + System.currentTimeMillis(), location, Settings.ADJUST_LIGHT_LEVEL, role, desiredLightLevel);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        activeECs.add(ec);
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = ec.getadjustLightByPerformer(location, role);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        realizeEC(role, performer, Settings.ADJUST_LIGHT_LEVEL_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);

    }

    public void advertiseBoatAds(String role, String location) throws Exception {
        String goalName = Settings.SHOW_BOATS_ADS;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        AdvertiseBoatAdsAbstractSchema ec = new AdvertiseBoatAdsAbstractSchema("showAdsOn" + location + "--" + System.currentTimeMillis(), location, role);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = ec.getBoatSchemaPerformer(location, role);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        realizeEC(role, performer, Settings.ADVERTISE_BOAT_ADS_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);

    }


    public void maintainTemperature(String role, String location, int desiredTemp) throws Exception {
        String goalName = Settings.MAINTAIN_TEMPERATURE;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        MaintainTemperatureAbstractSchema ec = new MaintainTemperatureAbstractSchema("maintainTemp" + location + "--" + System.currentTimeMillis(), location, Settings.MAINTAIN_TEMPERATURE, role, desiredTemp);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = ec.maintainTemperatureByPerformer(location, role, desiredTemp);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        realizeEC(role, performer, Settings.ADVERTISE_BOAT_ADS_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);

    }


    public void advertiseMuseum(String role, String location) throws Exception {
        String goalName = Settings.SHOW_MUSEUM_ADS;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        AdvertiseMuseumAbstractSchema ec = new AdvertiseMuseumAbstractSchema("showAdsOn" + location + "--" + System.currentTimeMillis(), location, role);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = ec.getMuseumSchemaPerformer(location, role);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        this.realizeEC(role, performer, Settings.ADVERTISE_MUSEUM_ADS_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);

    }

    public void AnalyzeIncident(String location, String role) throws Exception {
        String goalName = Settings.INCIDENT_ANALYSIS;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        ManageIncidentAbstractSchema ec = new ManageIncidentAbstractSchema(role + System.currentTimeMillis(), location, Settings.INCIDENT_ANALYSIS, role);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        ManageIncidentAbstractSchema emergentConfiguration = (ManageIncidentAbstractSchema) ec;
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = emergentConfiguration.getIncidentManagementPerformer(location, role);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        this.realizeEC(role, performer, Settings.MANAGE_INCIDENT_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);
    }


    public void givePresentation(String location, String role) throws Exception {
        String goalName = Settings.GIVE_PRESENTATION;
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();

        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(location);
        GivePresentationAbstractSchema ec = new GivePresentationAbstractSchema(role + System.currentTimeMillis(), location, Settings.GIVE_PRESENTATION, role);
        Iterator it = availableAgents.iterator();
        while (it.hasNext()) {
            Performer p = (Performer) it.next();
            ec.addPerformer(p);
        }
        GivePresentationAbstractSchema emergentConfiguration = (GivePresentationAbstractSchema) ec;
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = emergentConfiguration.getPresentationPerformer(location, role);
        Performer performer = ecPerformer.getValue();
        activeECsRequests.put(ecPerformer.getKey(), (Team) performer);
        this.realizeEC(role, performer, Settings.GIVE_PRESENTATION_ABSTRACT_SCHEMA, ecPerformer.getKey(), location, goalName);
    }

    public void realizeEC(String role, Performer performer, String abstractSchemaName, int requestId, String location, String goal) {
        com.intendico.gorite.Executor executor = new Executor(role + "_Executor-" + requestId + System.currentTimeMillis());
        executor.addPerformer(performer);

        ECInfoObject ECInfoObject = new ECInfoObject(location, abstractSchemaName, role, goal);
        teamPerformers.put(requestId, ECInfoObject);
        teamStatus.put(requestId, Settings.ACTIVE);
        boolean canExecutionContinue = detectAndResolveConflictsOfGoals(role, goal, requestId, location);
        teamExecutors.put(requestId, executor);
        if (!canExecutionContinue) {
            System.err.println("The execution of the EC can't continue due to conflict in goal");
            return;
        }
        formAndEnactEC(executor);
    }

    private synchronized boolean detectAndResolveConflictsOfGoals(String role, String goalName, int requestId, String location) {
        HashSet<String> goalsSubGoals = goalsDecomposition.get(goalName);
        if (goalsSubGoals == null) {
            goalsSubGoals = new HashSet<String>();
        }
        goalsSubGoals.add(goalName);
        HashSet<String> interseciton = new HashSet<>(singletonGoals);
        interseciton.retainAll(goalsSubGoals);
        if (interseciton.size() > 0) {
            HashSet<Integer> conflictingTeams = new HashSet<Integer>();
            for (Map.Entry me : teamPerformers.entrySet()) {
                int teamRequestId = (int) me.getKey();
                ECInfoObject infoObject = (ECInfoObject) me.getValue();
                if (location.equals(infoObject.getLocation()) && getTeamStatus(teamRequestId).equals(Settings.ACTIVE) && teamRequestId != requestId) {
                    String teamGoal = infoObject.getGoalName();
                    HashSet<String> decomposition = goalsDecomposition.get(teamGoal);
                    if (decomposition == null)
                        decomposition = new HashSet<String>();
                    HashSet<String> teamGoals = new HashSet<String>(decomposition);
                    teamGoals.add(teamGoal);
                    interseciton.retainAll(teamGoals);
                    if (interseciton.size() > 0) {
                        conflictingTeams.add(teamRequestId);

                    }
                }

            }

            if (conflictingTeams.size() > 0) {
                boolean resolved = applyConflictResolutionStrategy(new AbstractMap.SimpleEntry<Integer, HashSet<Integer>>(requestId, conflictingTeams), true);
                return resolved;
            }

        }

        return true;

    }

    public void formAndEnactEC(Executor ecExecutor) {
        ecExecutor.run();
    }

    public void handleAgentUnavailableOrCantAdaptSubTeam(ApplicationLevelAgent applicationLevelAgent, Integer requestId) throws Exception {
        Team ec = activeECsRequests.get(requestId);
        if (agentsManager == null)
            agentsManager = AgentsManager.getInstance();
        ArrayList<Performer> availableAgents = agentsManager.getAgentsInLocation(ec.location);
        Vector agents = new Vector();
        Iterator it = availableAgents.iterator();

        while (it.hasNext()) {
            agents.add(it.next());

        }
        ec.removePerformer(applicationLevelAgent.getName());
        ec.getTaskTeam(Settings.SUB_TEAM_X).updateFillers(agents);
    }

    public boolean applyConflictResolutionStrategy(AbstractMap.SimpleEntry<Integer, HashSet<Integer>> conflictingTeams, boolean goalConflict) {
        Integer requestId = conflictingTeams.getKey();
        Team requestingEc = activeECsRequests.get(requestId);
        if (requestingEc == null) {
            System.err.println("requesting EC is not found for request Id = " + requestId);
        }
        HashMap<Integer, Team> conflictingTeamsAndRequests = new HashMap<Integer, Team>();
        Iterator it = conflictingTeams.getValue().iterator();
        int requestingECRolePriority = rolesPriorities.get(requestingEc.getRole());
//        HashSet<Team> conflictingECs = new HashSet<Team>();
        while (it.hasNext()) {
            int reqId = (int) it.next();
            Team conflictingEc = activeECsRequests.get(reqId);
//            conflictingECs.add(conflictingEc);
            conflictingTeamsAndRequests.put(reqId, conflictingEc);
        }

        if (conflictingTeamsAndRequests.size() == 0)
            return true;

        AbstractMap.SimpleEntry<Integer, Team> ecWithLeastPriority = findECWithLeastPriority(conflictingTeamsAndRequests);
        int priorityOfEC2Role = rolesPriorities.get(ecWithLeastPriority.getValue().getRole());
        if (requestingECRolePriority > priorityOfEC2Role) {
            suspendEC(ecWithLeastPriority, goalConflict, requestId);
            return true;
        } else if (requestingECRolePriority == priorityOfEC2Role) {
            if (requestId < ecWithLeastPriority.getKey()) {
                suspendEC(ecWithLeastPriority, goalConflict, requestId);
                return true;
            }
        }
        return false;
    }

    private void suspendEC(AbstractMap.SimpleEntry<Integer, Team> ecAndRequest, boolean goalConflict, int powerTeam) {
        int requestId = ecAndRequest.getKey();
        //System.err.println("Suspending request Id = " + requestId + "becuase of = " + powerTeam );
        Executor executor = teamExecutors.get(requestId);
        // System.out.println("Suspending request Id = " + requestId + "executor.name = " + executor.name);
        if(executor != null)
         executor.stop(true);
        if (!goalConflict) {
            priorityQueue.add(ecAndRequest);
            setTeamStatus(requestId, Settings.SUSBENDED);
        }


    }

    private synchronized AbstractMap.SimpleEntry<Integer, Team> findECWithLeastPriority(HashMap<Integer, Team> conflictingECs) {
        //  System.err.println("conflictingECs.size = " + conflictingECs.size());
        Iterator<Map.Entry<Integer, Team>> iterator = conflictingECs.entrySet().iterator();
        Map.Entry<Integer, Team> entry = iterator.next();
        int requestId = entry.getKey();
        Team tWithLeastPriority = entry.getValue();
        boolean allSameRolePriority = true;
        while (iterator.hasNext()) {
            Map.Entry me2 = (Map.Entry) iterator.next();
            Team t = (Team) me2.getValue();
            if (rolesPriorities.get(t.getRole()) < rolesPriorities.get(tWithLeastPriority.getRole())) {
                tWithLeastPriority = t;
                requestId = (int) me2.getKey();
                allSameRolePriority = false;
            }
        }
        if (!allSameRolePriority)
            return new AbstractMap.SimpleEntry<Integer, Team>(requestId, tWithLeastPriority);


        if (allSameRolePriority) {
            Iterator<Map.Entry<Integer, Team>> iterator2 = conflictingECs.entrySet().iterator();

            while (iterator2.hasNext()) {
                Map.Entry me2 = (Map.Entry) iterator2.next();
                Team t = (Team) me2.getValue();
                int tReqId = (int) me2.getKey();
                if (tReqId < requestId) {
                    tWithLeastPriority = t;
                    requestId = tReqId;
                }

            }


        }
        return new AbstractMap.SimpleEntry<Integer, Team>(requestId, tWithLeastPriority);


    }

    public int getTeamRolePriorityByRequestId(int requestId) {
        return rolesPriorities.get(teamPerformers.get(requestId).getRole());
    }

    public int getTeamRolePriority(Team t1) {
        return rolesPriorities.get(t1.getRole());
    }

    public void setTeamStatus(int requestId, String status) {
        teamStatus.put(requestId, status);

        if (status.equals(Settings.COMPLETED) || status.equals(Settings.SUSBENDED)) {
            ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> map = ApplicationLevelAgent.getTeamsThings();

            for (Map.Entry me : map.entrySet()) {
                AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();
                if (key.getKey() == requestId) {
                    ConcurrentHashMap<Performer, HashSet<Capability>> teamMembers = (ConcurrentHashMap<Performer, HashSet<Capability>>) me.getValue();
                    Map.Entry<Performer, HashSet<Capability>> entry = teamMembers.entrySet().iterator().next();
                    ApplicationLevelAgent responsibleAgent = ((Thing) (entry.getKey())).getManagingAgent();
                    // System.out.println("decrementing _ requestId " + requestId);
                    responsibleAgent.decrementCapabilitiesUsage(teamMembers);
                }
            }

        }


    }

    public String getTeamStatus(int requestId) {
        return teamStatus.get(requestId);
    }
}
