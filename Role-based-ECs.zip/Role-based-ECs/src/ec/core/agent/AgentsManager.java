package ec.core.agent;

import com.intendico.gorite.Performer;
import ec.agents.applicationAgent.ApplicationLevelAgent;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

public class AgentsManager extends Performer implements Runnable {

    static ConcurrentHashMap<String, ArrayList> availableAgentsInLocations = new ConcurrentHashMap<String, ArrayList>();
    private static AgentsManager agentsManager = null;
    EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();

    private AgentsManager() {
    }

    private AgentsManager(String n) throws Exception {
        super(n);
    }

    public static AgentsManager getInstance() throws Exception {
        if (agentsManager == null)
            agentsManager = new AgentsManager("AgentsManager");
        return agentsManager;
    }


    public void run() {

        while (true) {
            try {

                //  Thread.sleep(100);

            } catch (Exception e) {
                e.printStackTrace();
            }


        }


    }

    private void initializeAgentManager() throws Exception {


    }

    public ArrayList<Performer> getAgentsInLocation(String location) {
        ArrayList<Performer> performers = new ArrayList<Performer>();
        performers.addAll(availableAgentsInLocations.get(location));
        return performers;
    }

    public void addAgents(String location, ArrayList newList) {
        ArrayList currentList = availableAgentsInLocations.get(location);
        if (currentList != null) {
            currentList.addAll(newList);
            availableAgentsInLocations.put(location, currentList);
        } else {
            availableAgentsInLocations.put(location, newList);

        }
    }

    public void addAgent(String location, ApplicationLevelAgent agent) {
        ArrayList currentList = availableAgentsInLocations.get(location);
        if (currentList != null) {
            if (!currentList.contains(agent))
                currentList.add(agent);
            availableAgentsInLocations.put(location, currentList);
        } else {
            ArrayList arrayList = new ArrayList<ApplicationLevelAgent>();
            arrayList.add(agent);
            availableAgentsInLocations.put(location, arrayList);
        }
    }
}
