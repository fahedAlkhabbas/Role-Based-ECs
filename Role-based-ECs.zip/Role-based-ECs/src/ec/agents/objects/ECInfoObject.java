package ec.agents.objects;

import com.intendico.gorite.Performer;

public class ECInfoObject {
    String location;
    String schemaName;
    String role;
    String goalName;

    public String getGoalName() {
        return goalName;
    }

    public void setGoalName(String goalName) {
        this.goalName = goalName;
    }

    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public ECInfoObject(String location, String schemaName, String role, String goalName) {
        this.location = location;
        this.schemaName = schemaName;
        this.role = role;
        this.goalName = goalName;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
