package ec.agents.objects;


import ec.core.agent.AgentsManager;
import ec.agents.applicationAgent.AdvertisingCompanyAgent;
import smart.things.Beacon;
import smart.things.SmartScreen;

import java.util.*;

// This class represents a place of interest (e.g., building, train) where IoT devices (e.g., screens and beacons) are used (e.g., to display advertisements)

public class Entity {

    static ArrayList<Entity> entitiesList = new ArrayList<Entity>();
    String location;
    String name;
    AgentsManager agentsManager;

    public Entity(int eId, int screensAndBeaconsNumber, String location) throws Exception {
        agentsManager= AgentsManager.getInstance();
        this.location = location;
        AdvertisingCompanyAgent advertisingCompanyAgent = new AdvertisingCompanyAgent("ACA"+eId);
        agentsManager.addAgent(location, advertisingCompanyAgent);
        this.name = "entity" + eId;
        int x = (eId * screensAndBeaconsNumber) + screensAndBeaconsNumber;
        for (int i = eId * screensAndBeaconsNumber; i < x; i++) {
            SmartScreen sc = new SmartScreen("screen" + i, location);
            Beacon bc = new Beacon("beacon" + i, location);
            advertisingCompanyAgent.addAvailableThing(sc);
            advertisingCompanyAgent.addAvailableThing(bc);
        }
        entitiesList.add(this);
    }
    public static Entity getEntity(String trainName) {
        Iterator it = entitiesList.iterator();
        while (it.hasNext()) {
            Entity t = (Entity) it.next();
            if (t.getEntityName().equals(trainName))
                return t;
        }
        return null;


    }

    public String getEntityName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

}
