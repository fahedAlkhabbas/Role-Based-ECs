package ec.agents.schema;

import com.intendico.gorite.*;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;

public class StreamAdsConcreteSchema extends Team {
    public String location = "";
    String goalName;
    TaskTeam subteamX = null;

    public StreamAdsConcreteSchema(String name, String location, String goalName, String role) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        subteamX = new TaskTeam() {
            {
                addRole(new Role(Settings.ADS_STREAMER, new String[]{Settings.STREAM_ADS}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.ADS_STREAMER);
                        Thing t = (Thing) p;
                        return capability == null && (t.getLocation().equals(location) || t.getLocation().equals("*")) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });


            }
        };
        setTaskTeam(Settings.SUB_TEAM_X, subteamX);
        /*----------------------------------------------------------*/
        Goal g = new SequenceGoal(Settings.STREAM_ADVERTISEMENT, new Goal[]{
                deploy(Settings.SUB_TEAM_X),
                new TeamGoal(Settings.ADS_STREAMER, Settings.STREAM_ADS),
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);
    }

    public static HashSet<String> getRequiredCapabilities() {
        HashSet<String> results = new HashSet<String>();
        results.add(Settings.STREAM_ADS);
        return results;
    }

    public Performer getStreamAdPerformer(String location, int requestId, String role) {
        String goalName = Settings.STREAM_ADVERTISEMENT;
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.STREAM_ADVERTISEMENT).setValue(Settings.ROLE, role).setValue(Settings.TYPE, Settings.CONCRETE).setValue(Settings.REQUEST_ID, requestId);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("stream", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        return this;

    }

}
