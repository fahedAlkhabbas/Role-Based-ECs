package ec.agents.schema;

import com.intendico.gorite.*;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;

public class AdjustLightConcreteSchema extends Team {

    public boolean isUnderExecution = true;
    String goalName;
    public String location = "";
    TaskTeam subteamX = null;

    public AdjustLightConcreteSchema(String name, String location, String goalName, String role) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        subteamX = new TaskTeam() {
            {
                addRole(new Role(Settings.LIGHT_LEVEL_DETECTOR, new String[]{Settings.DETECT_LIGHT_LEVEL}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.LIGHT_LEVEL_DETECTOR);
                        Thing t = (Thing) p;
                        return capability == null && t.getLocation().equals(location) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });
                addRole(new Role(Settings.LIGHT_LEVEL_CONTROLLER, new String[]{Settings.CONTROL_LIGHT_LEVEL}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.LIGHT_LEVEL_CONTROLLER);
                        Thing t = (Thing) p;
                        return capability == null && t.getLocation().equals(location) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });

            }
        };
        setTaskTeam(Settings.SUB_TEAM_X, subteamX);
        /*----------------------------------------------------------*/
        Goal g = new SequenceGoal(Settings.ADJUST_LIGHT_LEVEL, new Goal[]{
                deploy(Settings.SUB_TEAM_X),

                new TeamGoal(Settings.LIGHT_LEVEL_DETECTOR, Settings.DETECT_LIGHT_LEVEL),
                new TeamGoal(Settings.LIGHT_LEVEL_CONTROLLER, Settings.CONTROL_LIGHT_LEVEL),
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);
    }


    public Performer getAdjustLightPerformer(String location, int requestId, String role) {
        String goalName = Settings.ADJUST_LIGHT_LEVEL;
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.ADJUST_LIGHT_LEVEL).setValue(Settings.ROLE, role).setValue(Settings.TYPE, Settings.CONCRETE).setValue(Settings.REQUEST_ID, requestId);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("give", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        return this;

    }

    public static HashSet<String> getRequiredCapabilities(){
        HashSet <String> results = new HashSet<String>();
        results.add(Settings.DETECT_LIGHT_LEVEL);
        results.add(Settings.CONTROL_LIGHT_LEVEL);
        return  results;
    }

}
