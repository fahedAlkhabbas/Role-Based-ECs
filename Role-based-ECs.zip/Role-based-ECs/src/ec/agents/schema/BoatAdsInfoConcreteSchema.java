package ec.agents.schema;

import com.intendico.gorite.*;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;

public class BoatAdsInfoConcreteSchema extends Team {
    public String location;
    String goalName;
    TaskTeam subteamX = null;

    public BoatAdsInfoConcreteSchema(String name, String location, String goalName, String role) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        subteamX = new TaskTeam() {
            {
                addRole(new Role(Settings.BOATS_COUNTER, new String[]{Settings.STREAM_BOATS_COUNT}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.BOATS_COUNTER);
                        Thing t = (Thing) p;
                        return capability == null && (t.getLocation().equals(location) || t.getLocation().equals("*")) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });
                addRole(new Role(Settings.PEOPLE_COUNTER, new String[]{Settings.STREAM_PEOPLE_COUNT}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.PEOPLE_COUNTER);
                        Thing t = (Thing) p;
                        return capability == null && (t.getLocation().equals(location) || t.getLocation().equals("*")) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });
                addRole(new Role(Settings.TEMPARATURE_REPORTER, new String[]{Settings.MEASURE_TEMERATURE}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.TEMPARATURE_REPORTER);
                        Thing t = (Thing) p;
                        return capability == null && (t.getLocation().equals(location) || t.getLocation().equals("*")) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });


            }
        };
        setTaskTeam(Settings.SUB_TEAM_X, subteamX);
        /*----------------------------------------------------------*/
        Goal g = new SequenceGoal(Settings.PROVIDE_BOATS_AD_INFO, new Goal[]{
                deploy(Settings.SUB_TEAM_X),
                new TeamGoal(Settings.PEOPLE_COUNTER, Settings.STREAM_PEOPLE_COUNT),
                new TeamGoal(Settings.BOATS_COUNTER, Settings.STREAM_BOATS_COUNT),
                new TeamGoal(Settings.TEMPARATURE_REPORTER, Settings.MEASURE_TEMERATURE),
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);
    }
    public static HashSet<String> getRequiredCapabilities() {
        HashSet<String> results = new HashSet<String>();
        results.add(Settings.STREAM_PEOPLE_COUNT);
        results.add(Settings.STREAM_BOATS_COUNT);
        results.add(Settings.MEASURE_TEMERATURE);
        return results;
    }

    public Performer getBoatInfoPerformer(String location, int requestId, String role) {
        String goalName = Settings.PROVIDE_BOATS_AD_INFO;
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.PROVIDE_BOATS_AD_INFO).setValue(Settings.ROLE, role).setValue(Settings.TYPE, Settings.CONCRETE).setValue(Settings.REQUEST_ID, requestId);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("provide", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        return this;

    }

}
