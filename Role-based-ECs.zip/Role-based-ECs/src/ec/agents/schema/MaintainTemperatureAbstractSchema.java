package ec.agents.schema;

import com.intendico.gorite.*;
import com.intendico.gorite.addon.TimeTrigger;
import ec.core.agent.EmergentConfigurationsManager;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.applicationAgent.Request;
import util.Settings;

import java.util.AbstractMap;

public class MaintainTemperatureAbstractSchema extends Team {
    public String location;
    String goalName;
    TaskTeam teamX = null;
    int desiredTemperature =0;
    @Override
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public MaintainTemperatureAbstractSchema(String name, String location, String goalName, String role, int desiredTemperature) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        this.desiredTemperature = desiredTemperature;

        teamX = new TaskTeam() {
            {
                addRole(new Role(Settings.TEMPARATURE_ADJUSER, new String[]{Settings.MAINTAIN_TEMPERATURE_AUTONOMOUSLY}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability)
                                d.getValue(Settings.TEMPARATURE_ADJUSER);
                        ApplicationLevelAgent applicationLevelAgent = (ApplicationLevelAgent) p;
                        Request request = new Request();
                        request.setConcreteSchema(Settings.MANAGE_TEMPERATURE_CONCRETE_SCHEMA);
                        try {
                            request.setAvailableThings(applicationLevelAgent.getAvailableThingsInLocation(getLocation()));
                            return (capability == null)&& applicationLevelAgent.HasCorrespondingConcreteSchema(Settings.MANAGE_TEMPERATURE_CONCRETE_SCHEMA) && applicationLevelAgent.canFormSubTeam(request) && applicationLevelAgent.isAvailabile();
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }
                    }

                });

            }
        };

        setTaskTeam(Settings.TEAM_X, teamX);

        /*----------------------------------------------------------*/
        // in Gorite, there is a bug with the loop goal and it does not work independently. Therefore, as a workaround, we had to
        // put it within a parallelGoal.
        Goal g = new SequenceGoal(Settings.MAINTAIN_TEMPERATURE, new Goal[]{
                deploy(Settings.TEAM_X),
                new ParallelGoal("activities", new Goal[]{
                        new LoopGoal("loop", new Goal[]{
                                new TeamGoal(Settings.TEMPARATURE_ADJUSER, Settings.MAINTAIN_TEMPERATURE_AUTONOMOUSLY)
                        }),
                        new ControlGoal("ended", new Goal[]{
                                new Goal(Settings.GOAL_END) {
                                    public States execute(Data d) {
                                        if (TimeTrigger.isPending(d, "deadline", 1000)) {
                                            return States.BLOCKED;
                                        }
                                        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
                                        int requestId = (int) d.getValue(Settings.REQUEST_ID);
                                        ecm.setTeamStatus(requestId,Settings.COMPLETED);
                                        return States.PASSED;
                                    }
                                }

                        })

                })
        });



        addGoal(g);
        addTodoGroup(Settings.todogroup, null);


    }

    public AbstractMap.SimpleEntry<Integer, Performer> maintainTemperatureByPerformer (String location, String role, int desiredTemperature) {
        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
        String goalName = Settings.MAINTAIN_TEMPERATURE;
        int requestId = ecm.getRequest_id_generator();
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.MAINTAIN_TEMPERATURE).setValue(Settings.ROLE, role).setValue(Settings.REQUEST_ID, requestId).setValue(Settings.TYPE, Settings.ABSTRACT).setValue(Settings.DESIRED_TEMPERATURE, desiredTemperature);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("maintaint", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = new AbstractMap.SimpleEntry<Integer, Performer>(requestId, this);
        return ecPerformer;

    }
}


