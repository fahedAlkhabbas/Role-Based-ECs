package ec.agents.schema;

import com.intendico.gorite.*;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;

public class DisplayInfoConcreteSchema extends Team {
    public String location = "";
    String goalName;
    TaskTeam subteamX = null;

    public DisplayInfoConcreteSchema(String name, String location, String goalName, String role) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        subteamX = new TaskTeam() {
            {
                addRole(new Role(Settings.VIEWER, new String[]{Settings.DISPLAY_STREAM}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.VIEWER);
                        Thing t = (Thing) p;
                        // all possible devices that can display the advertisement should adopt the role VIEWER.
                       // System.err.println("t.getLocation() == " + t.getLocation() +  " Location = " + location);
                        return t.getLocation().equals(location) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });


            }
        };
        setTaskTeam(Settings.SUB_TEAM_X, subteamX);
        /*----------------------------------------------------------*/
        Goal g = new SequenceGoal(Settings.DISPLAY_ADVERTISEMENT, new Goal[]{
                deploy(Settings.SUB_TEAM_X),
                new TeamGoal(Settings.VIEWER, Settings.DISPLAY_STREAM),
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);
    }

    public static HashSet<String> getRequiredCapabilities() {
        HashSet<String> results = new HashSet<String>();
        results.add(Settings.DISPLAY_STREAM);
        return results;
    }

    public synchronized Performer getDisplayInfoPerformer(String location, int requestId, String role) {
        String goalName = Settings.DISPLAY_ADVERTISEMENT;
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.DISPLAY_ADVERTISEMENT).setValue(Settings.ROLE, role).setValue(Settings.TYPE, Settings.CONCRETE).setValue(Settings.REQUEST_ID, requestId);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("display", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        return this;

    }

}
