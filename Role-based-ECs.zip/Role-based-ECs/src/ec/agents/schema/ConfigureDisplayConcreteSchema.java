package ec.agents.schema;

import com.intendico.gorite.*;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;

public class ConfigureDisplayConcreteSchema extends Team {

    public boolean isUnderExecution = true;
    String goalName;
    String location ="";
    TaskTeam subteamY = null;

    public ConfigureDisplayConcreteSchema(String name, String location, String goalName, String role) throws Exception {
        super(name, role);
        this.goalName = goalName;
        //this.currentTime = java.util.Date.from(Instant.now());
        this.location = location;
        subteamY = new TaskTeam() {
            {
                addRole(new Role(Settings.PRESENTER, new String[]{Settings.STREAM_PRESENTATION}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.PRESENTER);
                        Thing t = (Thing) p;
                        return capability == null && t.getLocation().equals(location) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);

                    }

                });
                addRole(new Role(Settings.VIEWER, new String[]{Settings.DISPLAY_STREAM}){
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }
                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability) d.getValue(Settings.VIEWER);
                        Thing t = (Thing) p;
                        return capability == null && t.getLocation().equals(location) && t.isOperationalSatus() && t.isConnectionStatus() && (t.getBatteryLevel().equals("*") || Integer.parseInt(t.getBatteryLevel()) > Settings.BATTERY_THRESHOLD);
                    }

                });

            }
        };
        setTaskTeam(Settings.SUB_TEAM_X, subteamY);
        /*----------------------------------------------------------*/
        Goal g = new SequenceGoal(Settings.CONFIGURE_DISPLAY_MEDIA, new Goal[]{
                deploy(Settings.SUB_TEAM_X),
                                new TeamGoal(Settings.PRESENTER, Settings.STREAM_PRESENTATION),
                                new TeamGoal(Settings.VIEWER, Settings.DISPLAY_STREAM),
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);


    }


    public Performer getDisplayConfigurationPerformer(String location, int requestId, String role) {
        String goalName = Settings.CONFIGURE_DISPLAY_MEDIA;
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.CONFIGURE_DISPLAY_MEDIA).setValue(Settings.ROLE, role).setValue(Settings.TYPE, Settings.CONCRETE).setValue(Settings.REQUEST_ID, requestId);

        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("display", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        return this;

    }

    public static HashSet<String> getRequiredCapabilities(){
        HashSet <String> results = new HashSet<String>();
        results.add(Settings.STREAM_PRESENTATION);
        results.add(Settings.DISPLAY_STREAM);
        return  results;
    }
}
