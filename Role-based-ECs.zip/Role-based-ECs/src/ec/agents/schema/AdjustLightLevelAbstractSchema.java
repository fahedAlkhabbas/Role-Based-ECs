package ec.agents.schema;

import com.intendico.gorite.*;
import com.intendico.gorite.addon.TimeTrigger;
import ec.core.agent.EmergentConfigurationsManager;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.applicationAgent.Request;
import util.Settings;

import java.util.AbstractMap;

public class AdjustLightLevelAbstractSchema extends Team {
    public String location;
    String goalName;
    TaskTeam teamX = null;
    int desiredLightLevel =0;
    @Override
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }


    public AdjustLightLevelAbstractSchema(String name, String location, String goalName, String role, int desiredLightLevel) throws Exception {
        super(name, role);
        this.goalName = goalName;
        this.location = location;
        this.desiredLightLevel = desiredLightLevel;

        teamX = new TaskTeam() {
            {
                addRole(new Role(Settings.LIGHT_LEVEL_ADJUSTER, new String[]{Settings.ADJUST_LIGHT_AUTONOMOUSLY}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability)
                                d.getValue(Settings.LIGHT_LEVEL_ADJUSTER);
                        ApplicationLevelAgent applicationLevelAgent = (ApplicationLevelAgent) p;
                        Request request = new Request();
                        request.setConcreteSchema(Settings.ADJUST_LIGHT_CONCRETE_SCHEMA);
                        try {
                            request.setAvailableThings(applicationLevelAgent.getAvailableThingsInLocation(getLocation()));
                            return (capability == null)&& applicationLevelAgent.isAvailabile() && applicationLevelAgent.HasCorrespondingConcreteSchema(Settings.ADJUST_LIGHT_CONCRETE_SCHEMA) && applicationLevelAgent.canFormSubTeam(request);
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }
                    }

                });

            }
        };

        setTaskTeam(Settings.TEAM_X, teamX);

        /*----------------------------------------------------------*/

        // in Gorite, there is a bug with the loop goal and it does not work independently. Therefore, as a workaround, we had to
        // put it within a parallelGoal.

        Goal g = new SequenceGoal(Settings.ADJUST_LIGHT_LEVEL, new Goal[]{
                deploy(Settings.TEAM_X),
                new ParallelGoal("activities", new Goal[]{
                        new LoopGoal("loop", new Goal[]{
                                new TeamGoal(Settings.LIGHT_LEVEL_ADJUSTER, Settings.ADJUST_LIGHT_AUTONOMOUSLY)
                        }),
                        new ControlGoal("ended", new Goal[]{
                                new Goal(Settings.END_AD) {
                                    public Goal.States execute(Data d) {
                                        if (TimeTrigger.isPending(d, "deadline", 1000)) {
                                            //   System.err.println("ADVERTISEMENT is ongoing..." );
                                            return Goal.States.BLOCKED;
                                        }
                                        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
                                        int requestId = (int) d.getValue(Settings.REQUEST_ID);
                                        ecm.setTeamStatus(requestId,Settings.COMPLETED);
                                        return Goal.States.PASSED;
                                    }
                                }

                        })

                })
        });



        addGoal(g);
        addTodoGroup(Settings.todogroup, null);


    }

    public AbstractMap.SimpleEntry<Integer, Performer> getadjustLightByPerformer (String location, String role) {
        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
        String goalName = Settings.ADJUST_LIGHT_LEVEL;
        int requestId = ecm.getRequest_id_generator();
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.ADJUST_LIGHT_LEVEL).setValue(Settings.ROLE, role).setValue(Settings.REQUEST_ID, requestId).setValue(Settings.TYPE, Settings.ABSTRACT);

        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("adjustx", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = new AbstractMap.SimpleEntry<Integer, Performer>(requestId, this);
        return ecPerformer;

    }
}


