package ec.agents.schema;

import com.intendico.gorite.*;
import com.intendico.gorite.addon.TimeTrigger;
import ec.core.agent.EmergentConfigurationsManager;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.applicationAgent.Request;
import util.Settings;

import java.io.Serializable;
import java.util.AbstractMap;


public class AdvertiseMuseumAbstractSchema extends Team implements Serializable {

    TaskTeam teamX = null;
    String location;

    public AdvertiseMuseumAbstractSchema(String name, String location, String role) throws Exception {
        super(name, role, location, Settings.SHOW_MUSEUM_ADS);
        this.location = location;

        teamX = new TaskTeam() {
            {
                addRole(new Role(Settings.ADS_STREAMER_ROLE, new String[]{Settings.STREAM_ADD_AUTONOMOUSLY}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability)
                                d.getValue(Settings.ADS_STREAMER_ROLE);
                        ApplicationLevelAgent applicationLevelAgent = (ApplicationLevelAgent) p;
                        Request request = new Request();
                        request.setConcreteSchema(Settings.STREAM_AD_CONCRETE_SCHEMA);
                        try {
                            request.setAvailableThings(applicationLevelAgent.getAvailableThingsInLocation(getLocation()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            return (capability == null) && applicationLevelAgent.isAvailabile() && applicationLevelAgent.HasCorrespondingConcreteSchema(Settings.STREAM_AD_CONCRETE_SCHEMA) && applicationLevelAgent.canFormSubTeam(request);
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }

                    }

                });

                addRole(new Role(Settings.ADS_VIEWER_ROLE, new String[]{Settings.DISPLAY_INFO_AUTONOMOUSLY}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability)
                                d.getValue(Settings.ADS_VIEWER_ROLE);
                        ApplicationLevelAgent applicationLevelAgent = (ApplicationLevelAgent) p;
                        Request request = new Request();
                        request.setConcreteSchema(Settings.DISPLAY_INFO_CONCRETE_SCHEMA);
                        try {
                            request.setAvailableThings(applicationLevelAgent.getAvailableThingsInLocation(getLocation()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            return (capability == null) && applicationLevelAgent.HasCorrespondingConcreteSchema(Settings.DISPLAY_INFO_CONCRETE_SCHEMA) && applicationLevelAgent.canFormSubTeam(request);
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }

                    }

                });
                addRole(new Role(Settings.DISCOUNT_PUBLISHER_ROLE, new String[]{Settings.PUBLISH_DISCOUNTS_AUTONOMOUSLY}) {
                    public boolean canFill(Performer p) {
                        return p.hasGoals(required);
                    }

                    public boolean canAct(Data d, Performer p) {
                        Capability capability = (Capability)
                                d.getValue(Settings.DISCOUNT_PUBLISHER_ROLE);
                        ApplicationLevelAgent applicationLevelAgent = (ApplicationLevelAgent) p;
                        Request request = new Request();
                        request.setConcreteSchema(Settings.PUBLISH_DISCOUNTS_CONCRETE_SCHEMA);
                        try {
                            request.setAvailableThings(applicationLevelAgent.getAvailableThingsInLocation(getLocation()));
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        try {
                            return applicationLevelAgent.HasCorrespondingConcreteSchema(Settings.PUBLISH_DISCOUNTS_CONCRETE_SCHEMA) && applicationLevelAgent.canFormSubTeam(request);
                        } catch (Exception e) {
                            e.printStackTrace();
                            return false;
                        }

                    }

                });


            }
        };
        setTaskTeam(Settings.TEAM_X, teamX);
        Goal g = new SequenceGoal(Settings.SHOW_MUSEUM_ADS, new Goal[]{
                deploy(Settings.TEAM_X),
                new ParallelGoal("Parallel Activities", new Goal[]{
                        new LoopGoal("SD", new Goal[]{
                                new TeamGoal(Settings.ADS_STREAMER_ROLE, Settings.STREAM_ADD_AUTONOMOUSLY),
                                new TeamGoal(Settings.ADS_VIEWER_ROLE, Settings.DISPLAY_INFO_AUTONOMOUSLY),
                        }),
                        new LoopGoal(Settings.LIVE_INFO, new Goal[]{
                                new TeamGoal(Settings.DISCOUNT_PUBLISHER_ROLE, Settings.PUBLISH_DISCOUNTS_AUTONOMOUSLY),
                        }),
                        new ControlGoal(Settings.ADV_ENDED, new Goal[]{
                                new Goal(Settings.END_AD) {
                                    public States execute(Data d) {
                                        if (TimeTrigger.isPending(d, "deadline", 20)) {
                                            return States.BLOCKED;
                                        }

                                        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
                                        int requestId = (int) d.getValue(Settings.REQUEST_ID);
                                        ecm.setTeamStatus(requestId,Settings.COMPLETED);
                                        return States.PASSED;
                                    }
                                }

                        })

                })
        });
        addGoal(g);
        addTodoGroup(Settings.todogroup, null);


    }

    public AbstractMap.SimpleEntry<Integer, Performer> getMuseumSchemaPerformer(String location, String role) {
        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
        String goalName = Settings.SHOW_MUSEUM_ADS;
        int requestId = ecm.getRequest_id_generator();
        Data data = new Data().setValue(Settings.LOCATION, location).setValue(Settings.GOAL_TYPE, Settings.SHOW_MUSEUM_ADS).setValue(Settings.ROLE, role).setValue(Settings.REQUEST_ID, requestId).setValue(Settings.TYPE, Settings.ABSTRACT);
        BDIGoal goal = new BDIGoal(goalName);
        this.addGoal(goal);
        Goal.Instance goalInstance = goal.instantiate("show", data);
        goal.setGoalGroup(Settings.todogroup);
        TodoGroup todoGroup = getTodoGroup(Settings.todogroup);
        goalInstance.data = data;
        goalInstance.performer = this;
        data.link(goalInstance.thread_name);
        todoGroup.added.add(goalInstance);
        AbstractMap.SimpleEntry<Integer, Performer> ecPerformer = new AbstractMap.SimpleEntry<Integer, Performer>(requestId, this);
        return ecPerformer;
    }
}
