package ec.agents.applicationAgent;

import ec.agents.capability.ConfigureDisplayDevices;
import smart.things.*;
import util.Settings;

import java.util.HashSet;

public class DisplayManagementAgent extends ApplicationLevelAgent {
    public DisplayManagementAgent(String name) throws Exception {
        super(name);
        addCapability(new ConfigureDisplayDevices(this));
        initializeAgent();
    }

    public void initializeAgent() {
        try {
            supportedConcreteSchemas.add(Settings.CONFIUGRE_DISPLAY_CONCRETE_SCHEMA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public HashSet<Thing> getAvailableThingsInLocation(String location) throws Exception {
        return getThingsInLocation(location, availableThings);
    }


    @Override
    public boolean HasCorrespondingConcreteSchema(String schema) {
        return supportedConcreteSchemas.contains(schema);
    }

    @Override
    public void handleThingBecameUnavailable(Thing t) {

    }


}
