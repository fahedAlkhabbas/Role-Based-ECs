package ec.agents.applicationAgent;

import smart.things.Thing;

import java.util.HashSet;

public class Request {
    String id;
    ApplicationLevelAgent applicationLevelAgent;
    HashSet<Thing> availableThings = new HashSet<Thing>();
    String concreteSchema;
    String location;
    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getConcreteSchema() {
        return concreteSchema;
    }

    public void setConcreteSchema(String concreteSchema) {
        this.concreteSchema = concreteSchema;
    }

    public HashSet<Thing> getAvailableThings() {
        return availableThings;
    }

    public void setAvailableThings(HashSet<Thing> availableThings) {
        this.availableThings = availableThings;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

}
