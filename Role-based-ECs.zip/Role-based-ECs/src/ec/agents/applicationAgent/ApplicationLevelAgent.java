package ec.agents.applicationAgent;

import com.intendico.gorite.*;
import ec.core.agent.EmergentConfigurationsManager;
import service.Service;
import smart.things.*;
import util.Settings;

import java.lang.reflect.Method;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public abstract class ApplicationLevelAgent extends Performer {
    boolean availabilityStatus;
    static ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> teamsThings = new ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>>();
    static int j = 0;
    ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> subTeamsAgentRequests = new ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>>();
    HashSet<Thing> availableThings = new HashSet<Thing>();
    HashSet<String> supportedConcreteSchemas = new HashSet<String>();

    public boolean isAvailabile() {
        return availabilityStatus;
    }

    public ApplicationLevelAgent(String name) throws Exception {
        super(name);
        availabilityStatus = true;
    }

    public static ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> getTeamsThings() {
        return teamsThings;
    }

    public ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> getSubTeamsAgentRequests() {
        return subTeamsAgentRequests;
    }

    public void addAvailableThing(Thing thing) {
        availableThings.add(thing);
        thing.setManagingAgent(this);
    }

    public HashSet<String> getSupportedConcreteSchemas() {
        return supportedConcreteSchemas;
    }

    public void setSupportedConcreteSchemas(HashSet<String> supportedConcreteSchemas) {
        this.supportedConcreteSchemas = supportedConcreteSchemas;
    }


    public synchronized void addToSubTeamsAgentRequest(Integer requestId, ConcurrentHashMap<Performer, HashSet<Capability>> subteam, String goalType) {
        AbstractMap.SimpleEntry<Integer, String> fkey = null;

        for (Map.Entry me0 : subteam.entrySet()) {

            HashSet<Capability> caps = (HashSet) me0.getValue();

            if (caps.size() > 2) {
                System.out.println("why?");

            }
        }


        for (Map.Entry me : subTeamsAgentRequests.entrySet()) {
            AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();

            if (key.getKey() == requestId && key.getValue().equals(goalType)) {
                fkey = key;
            }
        }
        if (subTeamsAgentRequests.size() == 0 || fkey == null) {
            fkey = new AbstractMap.SimpleEntry<Integer, String>(requestId, goalType);
            subTeamsAgentRequests.put(fkey, subteam);
        }


    }

    public synchronized void addToTeamsThings(Integer requestId, ConcurrentHashMap<Performer, HashSet<Capability>> subteam, String goalType) {
        j++;

        AbstractMap.SimpleEntry<Integer, String> fkey = null;
        //   System.out.println("requestId  = " + requestId + "  and goalType = " + goalType);
        for (Map.Entry me : teamsThings.entrySet()) {
            AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();

            // System.out.println("***key.getKey()  = " + key.getKey() + "  key.getValue() = " + key.getValue());

            if (key.getKey() == requestId && key.getValue().equals(goalType)) {
                fkey = key;
                System.out.println("found for requestId  = " + requestId + "  and goalType = " + goalType);
            }
        }
//        if(fkey!= null){
//            teamsThings.remove()

//        }


        if (teamsThings.size() == 0 || fkey == null) {
            fkey = new AbstractMap.SimpleEntry<Integer, String>(requestId, goalType);
            teamsThings.put(fkey, subteam);


        }


    }


    public abstract HashSet<Thing> getAvailableThingsInLocation(String location) throws Exception;


    public void formAndEnactSubTeam(String user, Performer performer, Team subTeam) {
        com.intendico.gorite.Executor executor = new Executor(user + "_Executor-" + subTeam.name + System.currentTimeMillis());
        executor.addPerformer(performer);
        // AbstractMap.SimpleEntry<Team, ECStatus> ecStatusPair = new AbstractMap.SimpleEntry<>(subTeam, ECStatus.BEING_FORMED);
        // ecsExecutors.put(ecStatusPair, executor);
        //teamPerformers.put(subTeam, performer);
        executeSubTeam(executor);
    }

    public void executeSubTeam(Executor ecExecutor) {
        //  System.out.println("The state of the thread is " + ecExecutor.getState());
        ecExecutor.run();
        //   System.out.println("The state of the thread is " + ecExecutor.getState());
        //   System.out.println("The isAlive of the thread is " + ecExecutor.isAlive());
    }


    public abstract void initializeAgent();

    // to optimize the performance, we return only operational and connected things from agents. Other preconditions can be added here.
    public boolean canFormSubTeam(Request request) throws Exception {
        String concreteSchema = request.getConcreteSchema();
        Class<?> schemaClass = Class.forName("ec.agents.schema." + concreteSchema);
        Method method = schemaClass.getDeclaredMethod("getRequiredCapabilities", null);
        HashSet<String> requiredCapabilities = (HashSet<String>) method.invoke(null);
        HashSet<Thing> availableThings = request.getAvailableThings();
        HashSet<String> availableCapabilities = new HashSet<String>();
        Iterator it = availableThings.iterator();
        while (it.hasNext()) {
            Thing thing = (Thing) it.next();
            availableCapabilities.addAll(thing.getCapabilities());
        }
        Iterator it2 = requiredCapabilities.iterator();
        while (it2.hasNext()) {
            String capabliity = (String) it2.next();
            if (!availableCapabilities.contains(capabliity))
                return false;
        }
        return true;
    }

    public abstract boolean HasCorrespondingConcreteSchema(String adjustLightConcreteSchema);

    public HashSet<Thing> getThingsInLocation(String location, HashSet<Thing> availableThings) {
        HashSet<Thing> availableThingsInLocation = new HashSet<Thing>();
        Iterator it = availableThings.iterator();
        while (it.hasNext()) {
            Thing thing = (Thing) it.next();
            if ((thing.getLocation().equals(location) || thing.getLocation().equals("*")) && thing.isOperationalSatus() && thing.isConnectionStatus())
                availableThingsInLocation.add(thing);
        }
        return availableThingsInLocation;
    }

    public abstract void handleThingBecameUnavailable(Thing t);

    public void changeThingOperationalStatusListiner(Thing thing, String newStatus) {
        // operational_status.put(thing.getName(), newStatus);
        if (newStatus.equals(Settings.OFF)) {
            handleThingBecameUnavailable(thing);
        }
    }

    public void changeThingConnectivityStatusListiner(Thing thing, String newStatus) {
        //   connectivity_status.put(thing.getName(), newStatus);
        if (newStatus.equals(Settings.DISCONNECTED)) {
            handleThingBecameUnavailable(thing);

        }
    }

    public void changeThingLocationListiner(Thing thing, String newLocation) {
        //  operational_status.put(thing.getName(), newLocation);
        handleThingBecameUnavailable(thing);

    }


    public synchronized void incrementCapabilitiesUsage(int requestId, ConcurrentHashMap<Performer, HashSet<Capability>> things, String goalType) {
        try {
//            for (Map.Entry me : subTeamsAgentRequests.entrySet()) {
//                AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();
//                if (requestId == key.getKey() && goalType.equals(key.getValue())) {
//                    System.out.println("already incemented...");
//                }
//            }
            for (Map.Entry entry : things.entrySet()) { // Map.Entry<Performer, HashSet<Capability>> entry = things.entrySet().iterator().next();
                Thing t = (Thing) entry.getKey();
                HashSet<Capability> capabilities = (HashSet<Capability>) entry.getValue();
                Iterator cIterator = capabilities.iterator();
                outerloop:
                while (cIterator.hasNext()) { // loop capabilities
                    Capability capability = (Capability) cIterator.next();
                    String capabilityName = ((RoleFilling) capability).role.required[0];
                    Iterator it = t.getInner().iterator();
                    ApplicationLevelAgent applicationLevelAgent = t.getManagingAgent();
                    boolean thingHasConflict = false;
                    innerloop:
                    while (it.hasNext()) { // loop thing capabilities
                        Object next = it.next();
                        String cap_name = (String) next.getClass().getDeclaredField("cap_name").get(null);
                        if (cap_name.equals(capabilityName)) {
                            Method method = next.getClass().getMethod("getMaxNrOfConcExecutions", null);
                            String maxNrOfConcExecutions = (String) method.invoke(next, null);
                            if (maxNrOfConcExecutions.equals("*"))
                                continue innerloop;
                            Method method2 = next.getClass().getMethod("increaseCurrentConExecution", null);
                            method2.invoke(next, null);
                        }


                    }
                }


            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized void decrementCapabilitiesUsage(ConcurrentHashMap<Performer, HashSet<Capability>> things) {
        try {
            for (Map.Entry entry : things.entrySet()) { // Map.Entry<Performer, HashSet<Capability>> entry = things.entrySet().iterator().next();
                Thing t = (Thing) entry.getKey();
                // System.out.println("t name = " + t.getName());
                HashSet<Capability> capabilities = (HashSet<Capability>) entry.getValue();
                Iterator cIterator = capabilities.iterator();
                outerloop:
                while (cIterator.hasNext()) { // loop capabilities
                    Capability capability = (Capability) cIterator.next();
                    String capabilityName = ((RoleFilling) capability).role.required[0];
                    Iterator it = t.getInner().iterator();
                    ApplicationLevelAgent applicationLevelAgent = t.getManagingAgent();
                    boolean thingHasConflict = false;
                    innerloop:
                    while (it.hasNext()) { // loop thing capabilities
                        Object next = it.next();
                        String cap_name = (String) next.getClass().getDeclaredField("cap_name").get(null);
                        if (cap_name.equals(capabilityName)) {
                            Method method = next.getClass().getMethod("getMaxNrOfConcExecutions", null);
                            String maxNrOfConcExecutions = (String) method.invoke(next, null);
                            if (maxNrOfConcExecutions.equals("*"))
                                continue innerloop;
                            Method method2 = next.getClass().getMethod("decreaseCurrentConExecution", null);
                            method2.invoke(next, null);
                        }
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public synchronized boolean detectAndResolveConflicts(ConcurrentHashMap<Performer, HashSet<Capability>> things, int request_id) {
        try {
            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();

            exrernalLoop:
            for (Map.Entry entry : things.entrySet()) {
                Thing t = (Thing) entry.getKey();
                HashSet<Capability> capabilities = (HashSet<Capability>) entry.getValue();
                Iterator cIterator = capabilities.iterator();
                outerloop:
                while (cIterator.hasNext()) { // loop capabilities
                    Capability capability = (Capability) cIterator.next();
                    String capabilityName = ((RoleFilling) capability).role.required[0];
                    Iterator it = t.getInner().iterator();
                    ApplicationLevelAgent applicationLevelAgent = t.getManagingAgent();
                    boolean thingHasConflict = false;
                    innerloop:
                    while (it.hasNext()) { // loop thing capabilities
                        Object next = it.next();
                        String cap_name = (String) next.getClass().getDeclaredField("cap_name").get(null);
                        if (cap_name.equals(capabilityName)) {
                            boolean canExecutionContinue = checkConflictingCapabilities(t, cap_name, request_id);
                            if (!canExecutionContinue)
                                return false;
                            Method method = next.getClass().getMethod("getMaxNrOfConcExecutions", null);
                            String maxNrOfConcExecutions = (String) method.invoke(next, null);
                            if (maxNrOfConcExecutions.equals("*"))
                                continue innerloop;
                            Method method2 = next.getClass().getMethod("getCurrentConExecution", null);
                            int currentConExecution = (int) method2.invoke(next, null);
                            //  System.out.println("current Execution == " + currentConExecution);
                            if (currentConExecution >= Integer.parseInt(maxNrOfConcExecutions)) {
                                thingHasConflict = true;
                                break;
                            }
                        }
                    }
                    if (thingHasConflict) {
                        //  System.out.println("having conflict in thing ==== " + t.getName());
                        Method method3 = applicationLevelAgent.getClass().getMethod("getTeamsThings", null);
                        ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> subTeamsRequests = (ConcurrentHashMap) method3.invoke(applicationLevelAgent, null);
                        //System.err.println("Conflict detected");
                        HashSet<Integer> conflictingSubTeams = new HashSet<Integer>();
                        for (Map.Entry me : subTeamsRequests.entrySet()) {
                            AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();
                            int subTeamRequestId = key.getKey();
                            if (request_id != subTeamRequestId) {
                                ConcurrentHashMap<Performer, HashSet<Capability>> subTeams = (ConcurrentHashMap<Performer, HashSet<Capability>>) me.getValue();
                                if (ecm.getTeamStatus(subTeamRequestId).equals(Settings.ACTIVE)) {
                                    Iterator ity = subTeams.keySet().iterator();
                                    HashSet<String> teamNames = new HashSet<String>();
                                    while (ity.hasNext()) {
                                        Performer p = (Performer) ity.next();
                                        teamNames.add(p.getName());
                                    }
                                    if (teamNames.contains(t.getName())) {
                                        conflictingSubTeams.add(subTeamRequestId);
                                    }
                                }

                            }
                        }

                        if (conflictingSubTeams.size() == 0)
                            return true;

                        Capability.AddConflicts(request_id, conflictingSubTeams);


                        AbstractMap.SimpleEntry<Integer, HashSet<Integer>> conflictingTeams = new AbstractMap.SimpleEntry<Integer, HashSet<Integer>>(request_id, conflictingSubTeams);
                        //   System.out.println("conflictingSubTeams" + conflictingSubTeams.toString());
                        boolean canRequestingSubTeamExecute = ecm.applyConflictResolutionStrategy(conflictingTeams, false);
                        if (!canRequestingSubTeamExecute)
                            return false;


                    }


                }

            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("allowing execution in exception case!");
            return true;
        }
        //   System.err.println("No conflict has been detected");
        return true;
    }

    protected boolean checkConflictingCapabilities(Thing t, String cap_name, int request_id) {
        try {
            HashSet<String> conflictingCaps = t.getConflictingCapabilities().get(cap_name);
            if (conflictingCaps == null || conflictingCaps.size() == 0)
                return true;
            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
            ApplicationLevelAgent applicationLevelAgent = t.getManagingAgent();
            Method method3 = applicationLevelAgent.getClass().getMethod("getTeamsThings", null);
            ConcurrentHashMap<AbstractMap.SimpleEntry<Integer, String>, ConcurrentHashMap<Performer, HashSet<Capability>>> subTeamsRequests = (ConcurrentHashMap) method3.invoke(applicationLevelAgent, null);
            HashSet<Integer> conflictingSubTeams = new HashSet<Integer>();
            for (Map.Entry me : subTeamsRequests.entrySet()) {
                AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();
                int subTeamRequestId = key.getKey();
                if (request_id != subTeamRequestId) {
                    if ((ecm.getTeamStatus(subTeamRequestId).equals(Settings.ACTIVE))) {
                        ConcurrentHashMap<Performer, HashSet<Capability>> subTeams = (ConcurrentHashMap<Performer, HashSet<Capability>>) me.getValue();
                        for (Map.Entry me2 : subTeams.entrySet()) {
                            HashSet<Capability> activeCaps = (HashSet<Capability>) me2.getValue();
                            HashSet<String> activeCapsNames = new HashSet<String>();
                            Iterator itx = activeCaps.iterator();
                            while (itx.hasNext()) {
                                Capability capability = (Capability) itx.next();
                                String capabilityName = ((RoleFilling) capability).role.required[0];
                                activeCapsNames.add(capabilityName);
                            }
                            Set<String> intersection = new HashSet<String>(activeCapsNames);
                            intersection.retainAll(conflictingCaps);
                            if (intersection.size() > 0) {
                                System.err.println("Conflict detected between requestId = " + request_id + " and subTeamRequestId = " + subTeamRequestId);
                                conflictingSubTeams.add(subTeamRequestId);
                                AbstractMap.SimpleEntry<Integer, HashSet<Integer>> conflictingTeams = new AbstractMap.SimpleEntry<Integer, HashSet<Integer>>(request_id, conflictingSubTeams);
                                boolean canRequestingSubTeamExecute = ecm.applyConflictResolutionStrategy(conflictingTeams, false);
                                if (!canRequestingSubTeamExecute)
                                    return false;

                            }
                        }


                    }

                }


            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }


    public boolean hasTeamRequest(Integer requestId, String goalType) {
        for (Map.Entry me : subTeamsAgentRequests.entrySet()) {
            AbstractMap.SimpleEntry<Integer, String> key = (AbstractMap.SimpleEntry<Integer, String>) me.getKey();
            if (key.getKey() == requestId && key.getValue().equals(goalType)) {
                ConcurrentHashMap<Performer, HashSet<Capability>> teams = subTeamsAgentRequests.get(key);
                if (teams.size() > 0)
                    return true;
            }
        }
        return false;

//        HashSet<Team> existingTeams = subTeamsAgentRequests.get(requestId);
//
//        if(existingTeams== null)
//            return false;
//        if (existingTeams.get(goalType) != null)
//            return true;
//        return false;


    }


    // TODO: this function will be responsible for collecting the data from smart environment (e.g., temp sensors, heating status, etc) and pass it periodically to the
    // tuneActuators function (e.g., to tune devices that can adjust temperature).
    public void aggregateData(){

        analyzeDataAndTuneActuators(null);

    }
    // TODO: this function will be responsible for tuning ECs acutators to arrive to the goal in an optimal way. For example,
    //  the TemperatureAgent can override this function and pass the data passed by the aggregateData function
    //  to forecast temperature in smart scpaces and actuate actautors accordingly. The integration code with the service is added below
    //
    public void analyzeDataAndTuneActuators(ArrayList aggregatedData){

        Service service = new Service();
        service.forecastTemperature(aggregatedData);



    }
}