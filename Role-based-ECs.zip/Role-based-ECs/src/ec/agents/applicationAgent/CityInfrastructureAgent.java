package ec.agents.applicationAgent;

import com.intendico.gorite.Team;
import ec.core.agent.EmergentConfigurationsManager;
import ec.agents.capability.ProvideAdInfo;
import ec.agents.capability.ProvideIncidentInfo;
import ec.agents.schema.BoatAdsInfoConcreteSchema;
import ec.agents.schema.CollectIncidentInfoConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class CityInfrastructureAgent extends ApplicationLevelAgent {
    EmergentConfigurationsManager ecm;
    public CityInfrastructureAgent(String name) throws Exception {
        super(name);
        initializeAgent();
        ProvideAdInfo capability = new ProvideAdInfo(this);
        ProvideIncidentInfo capability2 = new ProvideIncidentInfo(this);
        addCapability(capability);
        addCapability(capability2);
        ecm = EmergentConfigurationsManager.getInstance();
    }


    @Override
    public void initializeAgent() {
        try {
            supportedConcreteSchemas.add(Settings.PROVIDE_AD_INFO_CONCRETE_SCHEMA);
            supportedConcreteSchemas.add(Settings.COLLECT_INCIDENT_INFO_CONCRETE_SCHEMA);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public HashSet<Thing> getAvailableThingsInLocation(String location) throws Exception {
        return getThingsInLocation(location, availableThings);
    }

    @Override
    public boolean HasCorrespondingConcreteSchema(String schema) {
        return supportedConcreteSchemas.contains(schema);
    }

    // if customized adaptations are needed to handle the event types, new methods are needed. Currently, the handleThingBecameUnavailable method handles the thing sudden disconnectivity, turn off, mobility, and running out of battery.
    // ToDo: move this method to the applicationLevelAgent class.
    @Override
    public void handleThingBecameUnavailable(Thing t) {
        try {
            String thingName = t.getName();
            Vector caps = this.getInner();
            for (Object element : caps) {
                if (element instanceof ProvideAdInfo) {
                    ProvideAdInfo provideInfoCapability = (ProvideAdInfo) element;
                    ConcurrentHashMap<Integer, Team> subTeamsRequests = provideInfoCapability.getSubTeamsRequests();
                    for (Map.Entry me : subTeamsRequests.entrySet()) {
                        Integer requestId = (Integer) me.getKey();
                        BoatAdsInfoConcreteSchema subTeam = (BoatAdsInfoConcreteSchema) me.getValue();
                        HashSet<String> subTeamConstiteuntNames = subTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames;
                        if (subTeamConstiteuntNames.contains(thingName)) {
                            String location = subTeam.location;
                            HashSet<Thing> availableThings = this.getAvailableThingsInLocation(location);
                            Request request = new Request();
                            request.setConcreteSchema(Settings.PROVIDE_AD_INFO_CONCRETE_SCHEMA);
                            request.setAvailableThings(availableThings);
                            subTeam.removePerformer(thingName);
                            if (canFormSubTeam(request)) {
                                Vector performers = new Vector();
                                Iterator it = availableThings.iterator();
                                while (it.hasNext()) {
                                    performers.add(it.next());

                                }
                                subTeam.getTaskTeam(Settings.SUB_TEAM_X).updateFillers(performers);
                                provideInfoCapability.addToSubTeamsRequest(requestId, subTeam);
                                System.err.println("Team adapted successfully!!");
                            } else {
                                System.err.println("Agent Can't adapt team autonomously - triggering event to ECM");
                                ecm.handleAgentUnavailableOrCantAdaptSubTeam(this, requestId);
                            }


                        }


                    }


                }
                if (element instanceof ProvideIncidentInfo) {
                    ProvideIncidentInfo provideIncidentInfoCapability = (ProvideIncidentInfo) element;
                    ConcurrentHashMap<Integer, Team> subTeamsRequests = provideIncidentInfoCapability.getSubTeamsRequests();
                    for (Map.Entry me : subTeamsRequests.entrySet()) {
                        Integer requestId = (Integer) me.getKey();
                        CollectIncidentInfoConcreteSchema subTeam = (CollectIncidentInfoConcreteSchema) me.getValue();
                        HashSet<String> subTeamConstiteuntNames = subTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames;
                        if (subTeamConstiteuntNames.contains(thingName)) {
                            String location = subTeam.location;
                            HashSet<Thing> availableThings = this.getAvailableThingsInLocation(location);
                            Request request = new Request();
                            request.setConcreteSchema(Settings.COLLECT_INCIDENT_INFO_CONCRETE_SCHEMA);
                            request.setAvailableThings(availableThings);
                            subTeam.removePerformer(thingName);
                            if (canFormSubTeam(request)) {
                                Vector performers = new Vector();
                                Iterator it = availableThings.iterator();
                                while (it.hasNext()) {
                                    performers.add(it.next());

                                }
                                subTeam.getTaskTeam(Settings.SUB_TEAM_X).updateFillers(performers);
                                provideIncidentInfoCapability.addToSubTeamsRequest(requestId, subTeam);
                                System.err.println("Team adapted successfully!!");
                            } else {
                                System.err.println("Agent Can't adapt team autonomously - triggering event to ECM");
                                ecm.handleAgentUnavailableOrCantAdaptSubTeam(this, requestId);
                            }


                        }


                    }


                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}




