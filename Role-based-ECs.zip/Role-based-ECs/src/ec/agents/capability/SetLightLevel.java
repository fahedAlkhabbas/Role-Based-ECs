package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.AdjustLightConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class SetLightLevel extends Capability {

    ApplicationLevelAgent applicationLevelAgent;
    String role;
    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();
    int i = 0;
    static HashSet<Integer> requestsForAdapt = new HashSet<Integer>();

    public SetLightLevel(ApplicationLevelAgent applicationLevelAgent) {

        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.ADJUST_LIGHT_AUTONOMOUSLY) {
            public Goal.States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
                //  System.out.println("requestId ==  " + requestId);
                String location = (String) d.getValue(Settings.LOCATION);
                int desiredLightLevel = 0;
                try {
                    adjustLight(location, desiredLightLevel, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ConcurrentHashMap<Integer, Team> getSubTeamsRequests() {
        return subTeamsRequests;
    }

    public void setSubTeamsRequests(ConcurrentHashMap<Integer, Team> subTeamsRequests) {
        this.subTeamsRequests = subTeamsRequests;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

    public void adjustLight(String location, int desiredLightLevel, Integer requestId) throws Exception {
        String goalName = Settings.ADJUST_LIGHT_LEVEL;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        AdjustLightConcreteSchema subteam = null;
        AdjustLightConcreteSchema existingSubTeam = (AdjustLightConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new AdjustLightConcreteSchema("Lorraine" + System.currentTimeMillis(), location, goalName, "Lorraine");
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        AdjustLightConcreteSchema emergentConfiguration = (AdjustLightConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getAdjustLightPerformer(location, requestId, role);
        applicationLevelAgent.formAndEnactSubTeam(role, performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }

        // the code of the if statement below turns of a device which triggers the adaptation process.
        // Comment it if not needed.
        if (!requestsForAdapt.contains(requestId)) {
            Map.Entry<Performer, HashSet<Capability>> entry = subteam.getTaskTeam(Settings.SUB_TEAM_X).teamMembers.entrySet().iterator().next();
            Thing t = (Thing) entry.getKey();
            System.err.println("Turning off ------------ " + t.getName());
            t.setOperationalSatus(false);
            requestsForAdapt.add(requestId);
        }

    }

    public void addToSubTeamsRequest(Integer requestId, Team subteam) {
        subTeamsRequests.put(requestId, subteam);

    }


}
