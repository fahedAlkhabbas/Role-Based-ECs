package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.CollectIncidentInfoConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class ProvideIncidentInfo extends Capability {
    ApplicationLevelAgent applicationLevelAgent;
    String role;
    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();

    public ProvideIncidentInfo(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.COLLECT_INFO_AUTONOMOUSLY) {
            public States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
             //   System.out.println("requestId ==  " + requestId);
                String location = (String) d.getValue(Settings.LOCATION);
                try {
                    provideIncidentInfo(location, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ConcurrentHashMap<Integer, Team> getSubTeamsRequests() {
        return subTeamsRequests;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

    public void provideIncidentInfo(String location, Integer requestId) throws Exception {
        String goalName = Settings.COLLECT_INFO;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        CollectIncidentInfoConcreteSchema subteam = null;
        CollectIncidentInfoConcreteSchema existingSubTeam = (CollectIncidentInfoConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new CollectIncidentInfoConcreteSchema(role
                    + System.currentTimeMillis(), location, goalName, role);
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        CollectIncidentInfoConcreteSchema emergentConfiguration = (CollectIncidentInfoConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getInfoProviderPerformer(location, requestId, role);
        applicationLevelAgent.formAndEnactSubTeam(role, performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }
      //  applicationLevelAgent.addToSubTeamsRequest(requestId, subteam);
    }

    public void addToSubTeamsRequest(Integer requestId, Team subteam) {
        subTeamsRequests.put(requestId, subteam);
      //  System.out.println("XXX");
    }


}
