package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.StreamAdsConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class StreamAdvertisement extends Capability {
    ApplicationLevelAgent applicationLevelAgent;
    String role;
    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();

    public StreamAdvertisement(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.STREAM_ADD_AUTONOMOUSLY) {
            public States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
              //  System.out.println("requestId ==  " + requestId);
                String location = (String) d.getValue(Settings.LOCATION);
                try {
                    streamAdvertisement(location, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ConcurrentHashMap<Integer, Team> getSubTeamsRequests() {
        return subTeamsRequests;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

    public void streamAdvertisement(String location, Integer requestId) throws Exception {
        String goalName = Settings.STREAM_ADVERTISEMENT;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        StreamAdsConcreteSchema subteam = null;
        StreamAdsConcreteSchema existingSubTeam = (StreamAdsConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new StreamAdsConcreteSchema(role
                    + System.currentTimeMillis(), location, goalName, "Lorraine");
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        StreamAdsConcreteSchema emergentConfiguration = (StreamAdsConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getStreamAdPerformer(location, requestId, role);
        applicationLevelAgent.formAndEnactSubTeam(role, performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }
     //   applicationLevelAgent.addToSubTeamsRequest(requestId, subteam);
    }

    public void addToSubTeamsRequest(Integer requestId, Team subteam) {
        subTeamsRequests.put(requestId, subteam);
        System.out.println("XXX");
    }


}
