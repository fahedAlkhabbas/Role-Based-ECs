package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.PublishDiscountsConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class ManageDiscounts extends Capability {
    ApplicationLevelAgent applicationLevelAgent;
    String role;
    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();
    public ManageDiscounts(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.PUBLISH_DISCOUNTS_AUTONOMOUSLY) {
            public States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
               // System.out.println("requestId ==  " + requestId);
                String location = (String) d.getValue(Settings.LOCATION);
                try {
                    publishDiscounts(location, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ConcurrentHashMap<Integer, Team> getSubTeamsRequests() {
        return subTeamsRequests;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

    public void publishDiscounts(String location, Integer requestId) throws Exception {
        String goalName = Settings.DISCOUNTS_ADVERTISEMENT;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        PublishDiscountsConcreteSchema subteam = null;
        PublishDiscountsConcreteSchema existingSubTeam = (PublishDiscountsConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new PublishDiscountsConcreteSchema(Settings.ADVERTISEMENT_REQUESTER
                    + System.currentTimeMillis(), location, goalName, Settings.ADVERTISEMENT_REQUESTER);
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        PublishDiscountsConcreteSchema emergentConfiguration = (PublishDiscountsConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getDiscountsPublisherPerformer(location, requestId, Settings.ADVERTISEMENT_REQUESTER);
        applicationLevelAgent.formAndEnactSubTeam(Settings.ADVERTISEMENT_REQUESTER, performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }
      //  applicationLevelAgent.addToSubTeamsRequest(requestId, subteam);
    }

    public void addToSubTeamsRequest(Integer requestId, Team subteam) {
        subTeamsRequests.put(requestId, subteam);
     //   System.out.println("XXX");
    }


}
