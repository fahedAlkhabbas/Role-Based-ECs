package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.ConfigureDisplayConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class ConfigureDisplayDevices extends Capability {

    ApplicationLevelAgent applicationLevelAgent;
    String role;
    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();
    public ConfigureDisplayDevices(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.CONFIGURE_DISPLAY_AUTONOMOUSLY) {
            public Goal.States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
                String location = (String) d.getValue(Settings.LOCATION);
                try {
                   configureDisplayMedia(location, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

//    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent, String user) {
//        this.applicationLevelAgent = applicationLevelAgent;
//        this.role = user;
//    }

    public void configureDisplayMedia(String location, int requestId) throws Exception {
        String goalName = Settings.CONFIGURE_DISPLAY_MEDIA;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        ConfigureDisplayConcreteSchema subteam = null;

        ConfigureDisplayConcreteSchema existingSubTeam = (ConfigureDisplayConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new ConfigureDisplayConcreteSchema("role"
                    + System.currentTimeMillis(), location, goalName,  role
            );
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        ConfigureDisplayConcreteSchema emergentConfiguration = (ConfigureDisplayConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getDisplayConfigurationPerformer(location, requestId, "dsad");
        applicationLevelAgent.formAndEnactSubTeam("ddd", performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }

        //    applicationLevelAgent.addToSubTeamsRequest(requestId, subteam);

    }


}
