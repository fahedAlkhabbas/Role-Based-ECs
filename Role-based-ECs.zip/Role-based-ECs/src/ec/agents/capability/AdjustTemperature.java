package ec.agents.capability;

import com.intendico.gorite.*;
import ec.agents.applicationAgent.ApplicationLevelAgent;
import ec.agents.schema.MaintainTemperatureConcreteSchema;
import smart.things.Thing;
import util.Settings;

import java.util.HashSet;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;

public class AdjustTemperature extends Capability {

    static HashSet<Integer> requestsForAdapt = new HashSet<Integer>();
    ApplicationLevelAgent applicationLevelAgent;

    ConcurrentHashMap<Integer, Team> subTeamsRequests = new ConcurrentHashMap<Integer, Team>();
    int i = 0;

    public AdjustTemperature(ApplicationLevelAgent applicationLevelAgent) {


        this.applicationLevelAgent = applicationLevelAgent;
        addGoal(new Plan(Settings.MAINTAIN_TEMPERATURE_AUTONOMOUSLY) {
            public States execute(Data d) {
                Integer requestId = (Integer) d.getValue(Settings.REQUEST_ID);
                String location = (String) d.getValue(Settings.LOCATION);
                int desiredTemp = 0;
                try {
                    maintainTemp(location, desiredTemp, requestId);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return States.PASSED;
            }
        });
    }

    public ConcurrentHashMap<Integer, Team> getSubTeamsRequests() {
        return subTeamsRequests;
    }

    public void setSubTeamsRequests(ConcurrentHashMap<Integer, Team> subTeamsRequests) {
        this.subTeamsRequests = subTeamsRequests;
    }

    public ApplicationLevelAgent getApplicationLevelAgent() {
        return applicationLevelAgent;
    }

    public void setApplicationLevelAgent(ApplicationLevelAgent applicationLevelAgent) {
        this.applicationLevelAgent = applicationLevelAgent;
    }

    public void maintainTemp(String location, int desiredTemp, Integer requestId) throws Exception {
        String goalName = Settings.ADJUST_TEMPERATURE_LEVEL;
        HashSet<Thing> availableThings = this.getApplicationLevelAgent().getAvailableThingsInLocation(location);
        MaintainTemperatureConcreteSchema subteam = null;
        MaintainTemperatureConcreteSchema existingSubTeam = (MaintainTemperatureConcreteSchema) subTeamsRequests.get(requestId);
        if (existingSubTeam != null) {
            subteam = existingSubTeam;
            //System.out.println("using an existing subteam" + existingSubTeam.getTaskTeam(Settings.SUB_TEAM_X).teamMembersNames.toString());
        } else {
            subteam = new MaintainTemperatureConcreteSchema("adjustT" + System.currentTimeMillis(), location, goalName, null);
            Iterator it = availableThings.iterator();
            while (it.hasNext()) {
                Performer p = (Performer) it.next();
                subteam.addPerformer(p);
            }

        }
        MaintainTemperatureConcreteSchema emergentConfiguration = (MaintainTemperatureConcreteSchema) subteam;
        Performer performer = emergentConfiguration.getMaintainTemperaturePerformer(location, requestId, null);
        applicationLevelAgent.formAndEnactSubTeam(null, performer, subteam);
        if (existingSubTeam == null) {
            subTeamsRequests.put(requestId, subteam);
        }

    }

    public void addToSubTeamsRequest(Integer requestId, Team subteam) {
        subTeamsRequests.put(requestId, subteam);

    }


}
