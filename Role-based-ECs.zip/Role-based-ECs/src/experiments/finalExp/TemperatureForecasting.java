package experiments.finalExp;

// this class shows the integration of the framework with the temperature forecast model.
// note that the IP of the service provider should be adjusted in the Service class.
// Also, the MachineLearningService in the ML project should be started.
// As part of our future work, this service will be used to tune HVAC services to realize Optimal ECs.
// We show in the application Level agent two methods that will be ovverritten for this purpose, namely, aggregateData and analyzeDataAndTuneActuators.


import service.Service;

public class TemperatureForecasting {

    public static void main(String[] args) {
        Service service = new Service();
        service.forecastTemperature(null);

    }


}
