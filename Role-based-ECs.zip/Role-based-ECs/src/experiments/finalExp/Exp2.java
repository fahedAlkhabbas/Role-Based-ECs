package experiments.finalExp;

import com.intendico.gorite.Executor;
import ec.core.agent.EmergentConfigurationsManager;
import ec.bootstraping.Initializer;
import experiments.threads.IncidentAnalysisThread;
import experiments.threads.ShowBoatAdThread;
import experiments.threads.ShowMuseumAdThread;
import ec.agents.objects.Entity;
import util.Settings;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Smart city experiment (Case 1)

public class Exp2 {
    public static void main(String[] args) {
        try {

            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
            Thread thread = new Thread(ecm);
            thread.start();
            Executor ecmExecutor = new Executor("ECM");
            ecmExecutor.addPerformer(ecm);
            ecmExecutor.start();


            Initializer initializer = new Initializer();

            initializer.initializeAgentManager(2, 100,0);
            ArrayList<Entity> entities = initializer.getEntities();
            List<Thread> threads = new ArrayList<Thread>();
            Iterator it = entities.iterator();
            long startTime = System.currentTimeMillis();

            Thread t1 = new IncidentAnalysisThread("location0", Settings.AUTHORITY);
            t1.start();
            threads.add(t1);

            while (it.hasNext()) {
                Entity entity = (Entity) it.next();

                Thread t2 = new ShowMuseumAdThread(Settings.ADVERTISEMENT_REQUESTER, entity.getLocation());
                t2.start();
                threads.add(t2);



                Thread t3 = new ShowBoatAdThread(Settings.ADVERTISEMENT_REQUESTER, entity.getLocation());
                t3.start();
                threads.add(t3);


            }


            for (Thread t : threads) {
                t.join();
            }


            // - In entities (e.g., smart buildings), only one advertisement can be played at a time and the other will be waiting due to the conflicts.
            // Thus, we substract 2x from the total time, where x is the time for displaying an advertisement.
            // - We also considered that all threads run in parallel. Thus, we substract only 2x.
            // - If this experiment is run on a device that has less processing capabilities than those in the paper, a bigger number should be substracted.
            //            - We set the advertisement duration to 20 millisecond as we are not interested in reporting the time for giving presentations but focus on the
            //  time the approach needs to form and orchestrate ECs enactment. When increasing the duration, it is not easy to know the number of threads
            // that run in parallel, which is needed to calculate the final consumed time.
            // - When setting the time to 20 milliseconds, all tasks in ECs are executed (multiple times if needed) as can be seen in the console and NO task is skipped.
            // - When increasing the duration, the the approach's scalability remains linear and the average time is in the scale of milliseconds (even if we substract the time of only two advertisements).
            // You may try by increasing the time the AdvertiseBoatAdsAbstractSchema, AdvertiseMuseumAbstractSchema, ManageIncidentAbstractSchema, and below.




            long finalConsumedTime = System.currentTimeMillis() - startTime - 40;
            System.out.println("Average consumed time = " + finalConsumedTime/201);
            System.exit(0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}