package experiments.finalExp;


//This class experiments detecting and resolving conflicts among singleton goals. For instance, you may change the
// priority of the guest in the ECM and notice the change in the execution.

import com.intendico.gorite.Executor;
import ec.bootstraping.Initializer;
import ec.core.agent.EmergentConfigurationsManager;
import experiments.threads.AdjustLightThread;
import experiments.threads.GivePresentationThread;
import util.Settings;

import java.util.ArrayList;
import java.util.List;

public class Exp5 {


    public static void main(String[] args) {
        try {
            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
            Thread thread = new Thread(ecm);
            thread.start();
            Executor ecmExecutor = new Executor("ECM");
            ecmExecutor.addPerformer(ecm);
            ecmExecutor.start();


            Initializer initializer = new Initializer();

            initializer.initializeAgentManager(5, 0, 0);
            List<Thread> threads = new ArrayList<Thread>();
            long startTime = System.currentTimeMillis();

            Thread t = new GivePresentationThread(ecm, Settings.SPEAKER, "room1");
            t.start();
            threads.add(t);
            Thread.sleep(5);
            Thread t3 = new AdjustLightThread(ecm, Settings.GUEST, "room1", 10);
            t3.start();
            threads.add(t3);
            for (Thread k : threads) {
                k.join();
            }

            System.exit(0);

        } catch (Exception e) {
            e.printStackTrace();

        }


    }


}
