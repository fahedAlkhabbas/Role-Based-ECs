package experiments.finalExp;

import ec.core.agent.EmergentConfigurationsManager;
import ec.bootstraping.Initializer;
import experiments.threads.MaintainTempThread;
import util.Settings;

public class EXP4 {
    public static void main(String[] args) {
        try {

            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
            Thread thread = new Thread(ecm);
            thread.start();


            Initializer initializer = new Initializer();

            initializer.initializeAgentManager(4, 0,0);

            Thread t1 = new MaintainTempThread(Settings.JANITOR, "room1",22);
            t1.start();



        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}