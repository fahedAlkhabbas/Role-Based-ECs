package experiments.finalExp;

import com.intendico.gorite.Executor;
import ec.core.agent.EmergentConfigurationsManager;
import ec.bootstraping.Initializer;
import experiments.threads.ShowBoatAdThread;
import ec.agents.objects.Entity;
import util.Settings;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// Smart city experiment (Case 2)

public class Exp3 {
    public static void main(String[] args) {
        try {


            Initializer initializer = new Initializer();
            EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
            Thread thread = new Thread(ecm);
            thread.start();
            Executor ecmExecutor = new Executor("ECM");
            ecmExecutor.addPerformer(ecm);
            ecmExecutor.start();
            int numberOfCompaniesRequestingAds = 10;
            int numberOfEntities = 15;
            initializer.initializeAgentManager(3, numberOfEntities ,numberOfCompaniesRequestingAds);
            ArrayList<Entity> entities = initializer.getEntities();
            List<Thread> threads = new ArrayList<Thread>();
            Iterator it = entities.iterator();

            long startTime = System.currentTimeMillis();
            while (it.hasNext()) {
                Entity entity = (Entity) it.next();
                for (int z = 0; z < numberOfCompaniesRequestingAds; z++) {
                    Thread t = new ShowBoatAdThread(Settings.ADVERTISEMENT_REQUESTER, entity.getLocation());
                    t.start();
                    threads.add(t);


                }
            }

            for (Thread t : threads) {
                t.join();
            }

            // - in entities (e.g., smart buildings), the advertisement of one company will be displayed and the advertisements of other companies will be waiting and enacted according to their request time.
            // Thus, we substract numberOfCompanies * x from the total time, where x is the time for displaying an advertisement.
            // - We also considered that all threads run in parallel. Thus, we substract only numberOfCompanies * x.
            // - If this experiment is run on a device that has less processing capabilities than those in the paper, a bigger number should be substracted.
            // - We set the advertisement duration to 20 millisecond as we are not interested in reporting the time for giving presentations but focus on the
            //  time the approach needs to form and orchestrate ECs enactment. When increasing the duration, it is not easy to know the number of threads
            // that run in parallel, which is needed to calculate the final consumed time.
            // - When setting the time to 20 milliseconds, all tasks in ECs are executed (multiple times if needed) as can be seen in the console and NO task is skipped.
            // - When increasing the duration, the the approach's scalability remains linear and the average time is in the scale of milliseconds (even if we substract the time of only number of companies * advertisement duration).
            // You may try by increasing the time the AdvertiseBoatAdsAbstractSchema and below.

            long averageConsumedTime = System.currentTimeMillis() - startTime  - (numberOfCompaniesRequestingAds *20);
            System.out.println("Average consumed time = " + averageConsumedTime/(numberOfCompaniesRequestingAds * numberOfEntities));

             System.exit(0);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}