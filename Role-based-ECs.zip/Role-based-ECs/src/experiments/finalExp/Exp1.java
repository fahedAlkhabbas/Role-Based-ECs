package experiments.finalExp;


// Smart building experiment
// This experiment simulates forming, adapting, and orchestrating the stateless enactment of
// 20 ECs to give 20 presentations. In the console you can see that for each EC, a constituent is turned off
// and the EC is adapted successfully.

import ec.core.agent.EmergentConfigurationsManager;
import ec.bootstraping.Initializer;
import experiments.threads.GivePresentationThread;
import util.Settings;

import java.util.ArrayList;
import java.util.List;

public class Exp1 {
    public static void main(String[] args) {
        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
        try {
            Initializer initializer = new Initializer();
            initializer.startECM();
            initializer.initializeAgentManager(1, 0,0);

            long startTime = System.currentTimeMillis();

            List<Thread> threads = new ArrayList<Thread>();
            Thread t = new GivePresentationThread(ecm, Settings.SPEAKER, "room1");
            t.start();
            threads.add(t);


            Thread t2 = new GivePresentationThread(ecm, Settings.SPEAKER, "room2");
            t2.start();
            threads.add(t2);

            Thread t3 = new GivePresentationThread(ecm, Settings.SPEAKER, "room3");
            t3.start();
            threads.add(t3);

            Thread t4 = new GivePresentationThread(ecm, Settings.SPEAKER, "room4");
            t4.start();
            threads.add(t4);

            Thread t5 = new GivePresentationThread(ecm, Settings.SPEAKER, "room5");
            t5.start();
            threads.add(t5);

            Thread t6 = new GivePresentationThread(ecm, Settings.SPEAKER, "room6");
            t6.start();
            threads.add(t6);

            Thread t7 = new GivePresentationThread(ecm, Settings.SPEAKER, "room7");
            t7.start();
            threads.add(t7);

            Thread t8 = new GivePresentationThread(ecm, Settings.SPEAKER, "room8");
            t8.start();
            threads.add(t8);

            Thread t9 = new GivePresentationThread(ecm, Settings.SPEAKER, "room9");
            t9.start();
            threads.add(t9);

            Thread t10 = new GivePresentationThread(ecm, Settings.SPEAKER, "room10");
            t10.start();
            threads.add(t10);

            Thread t11 = new GivePresentationThread(ecm, Settings.SPEAKER, "room11");
            t11.start();
            threads.add(t11);

            Thread t12 = new GivePresentationThread(ecm, Settings.SPEAKER, "room12");
            t12.start();
            threads.add(t12);

            Thread t13 = new GivePresentationThread(ecm, Settings.SPEAKER, "room13");
            t13.start();
            threads.add(t13);

            Thread t14 = new GivePresentationThread(ecm, Settings.SPEAKER, "room14");
            t14.start();
            threads.add(t14);

            Thread t15 = new GivePresentationThread(ecm, Settings.SPEAKER, "room15");
            t15.start();
            threads.add(t15);

            Thread t16 = new GivePresentationThread(ecm, Settings.SPEAKER, "room16");
            t16.start();
            threads.add(t16);

            Thread t17 = new GivePresentationThread(ecm, Settings.SPEAKER, "room17");
            t17.start();
            threads.add(t17);


            Thread t18 = new GivePresentationThread(ecm, Settings.SPEAKER, "room18");
            t18.start();
            threads.add(t18);

            Thread t19 = new GivePresentationThread(ecm, Settings.SPEAKER, "room19");
            t19.start();
            threads.add(t19);

            Thread t20 = new GivePresentationThread(ecm, Settings.SPEAKER, "room20");
            t20.start();
            threads.add(t20);
            for (Thread k : threads) {
                k.join();
            }

            // - We considered that all threads run in parallel. Thus, we substract only the time for giving one presentation.
            // - If this experiment is run on a device that has less processing capabilities than those in the paper, you need to substract a bigger number.
            // - We set the presentation duration to 20 millisecond as we are not interested in reporting the time for giving presentations but focus on the
            //  time the approach needs to form and orchestrate ECs enactment. When increasing the duration, it is not easy to know the number of threads
            // that run in parallel, which needed to calculate the final consumed time.
            // - When setting the time to 20 milliseconds, all tasks in ECs are executed (multiple times if needed) as can be seen in the console and NO task is skipped.
            // - When increasing the duration, the the approach's scalability remains linear and the average time is in the scale of millisecond (even if we substract the time of only one presentation).
            // You may try by increasing the time the GivePresentationAbstractSchema and below.




            long finalConsumedTime = System.currentTimeMillis() - startTime - 20;
            System.out.println("average consumed time = " + finalConsumedTime / 20);

        } catch (Exception e) {
            e.printStackTrace();
        }



    }


}
