package experiments.threads;

import ec.core.agent.EmergentConfigurationsManager;

public class MaintainTempThread extends Thread {

    static long totalElabsedtime = 0L;
    EmergentConfigurationsManager ecm;
    boolean isTriggered = false;
    String role;
    String location;
    int desiredTemp;

    public MaintainTempThread( String role, String location, int desiredTemp) {
        this.ecm = ecm = EmergentConfigurationsManager.getInstance();
        this.role = role;
        this.location = location;
        this.desiredTemp = desiredTemp;
    }

    public void run() {
        this.maintainTemp(this.role, this.location, this.desiredTemp);
    }

    public void maintainTemp(String role, String location, int desiredTemp) {
        try {
            ecm.maintainTemperature(role, location, desiredTemp);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
