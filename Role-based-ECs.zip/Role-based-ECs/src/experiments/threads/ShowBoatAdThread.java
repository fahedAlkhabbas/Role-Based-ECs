package experiments.threads;

import ec.core.agent.EmergentConfigurationsManager;
import ec.agents.objects.Entity;

public class ShowBoatAdThread extends Thread {

    EmergentConfigurationsManager ecm;

    Entity entity;
    String role;
    static long totalElabsedtime  = 0L;
    String location ;
    public ShowBoatAdThread(Entity entity, String role, String location) {
        this.ecm = EmergentConfigurationsManager.getInstance();
        this.entity = entity;
        this.role = role;
        this.location = location;
    }
    public ShowBoatAdThread(String role, String location) {
        this.ecm = EmergentConfigurationsManager.getInstance();

        this.role = role;
        this.location = location;
    }

    public static long getTotalElabsedtime() {
        return totalElabsedtime;
    }

    public void run() {

        try {

//                this.show_ad(this.entity, this.role, this.location);
                this.show_ad(this.role, this.location);

        } catch (Exception f) {
            f.printStackTrace();

        }

    }

    public void show_ad(String role, String  location) {
     try {
            ecm.advertiseBoatAds(role, location);
            } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
