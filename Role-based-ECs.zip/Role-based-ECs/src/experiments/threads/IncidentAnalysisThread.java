package experiments.threads;

import ec.core.agent.EmergentConfigurationsManager;

public class IncidentAnalysisThread extends Thread {
    EmergentConfigurationsManager ecm;
    String role;
    String location;

    public IncidentAnalysisThread(String location, String role) {
        this.ecm = EmergentConfigurationsManager.getInstance();
        this.role = role;
        this.location = location;

    }
    public void run() {
        try {
            this.analyzeEvent();
        } catch (Exception f) {
            f.printStackTrace();

        }
    }

    public void analyzeEvent() {
        try {
            ecm.AnalyzeIncident(location, role);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
