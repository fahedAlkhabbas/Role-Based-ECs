package experiments.threads;

import ec.core.agent.EmergentConfigurationsManager;

public class GivePresentationThread extends Thread {

    EmergentConfigurationsManager ecm;
    String user;
    String location;

    public GivePresentationThread(EmergentConfigurationsManager ecm, String user, String location) {
        this.ecm = ecm;
        this.user = user;
        this.location = location;
    }

    public void run() {
        this.give_presentatino(this.user, this.location);
   }

    public void give_presentatino(String user, String location) {
        try {
            ecm.givePresentation(location, user);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
