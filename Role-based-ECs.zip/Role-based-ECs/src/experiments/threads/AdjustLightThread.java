package experiments.threads;

import ec.core.agent.EmergentConfigurationsManager;

public class AdjustLightThread extends Thread {

    static long totalElabsedtime = 0L;
    EmergentConfigurationsManager ecm;
    boolean isTriggered = false;
    String role;
    String location;
    int desiredLightLevel;

    public AdjustLightThread(EmergentConfigurationsManager ecm, String role, String location, int desiredLightLevel) {
        this.ecm = ecm;
        this.role = role;
        this.location = location;
        this.desiredLightLevel = desiredLightLevel;
    }

    public void run() {
        this.adjustLight(this.role, this.location, this.desiredLightLevel);
   }

    public void adjustLight(String role, String location, int desiredLightLevel) {
        try {
            ecm.adjustLight( role, location, desiredLightLevel);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }
}
