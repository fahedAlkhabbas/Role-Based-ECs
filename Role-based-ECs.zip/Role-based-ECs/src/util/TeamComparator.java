package util;

import com.intendico.gorite.Team;
import ec.core.agent.EmergentConfigurationsManager;

import java.util.AbstractMap;
import java.util.Comparator;

public class TeamComparator implements Comparator<AbstractMap.SimpleEntry<Integer, Team>> {
    @Override
    public int compare(AbstractMap.SimpleEntry<Integer, Team> o1, AbstractMap.SimpleEntry<Integer, Team> o2) {

        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();
       Team t1 = o1.getValue();
       Team t2 = o2.getValue();

        int r1 = ecm.getTeamRolePriority(t1);
        int r2 = ecm.getTeamRolePriority(t2);

        if (r1 == r2) {
            if (t1.isFormedBeofre(t2)) {
                return -1;
            } else {
                return 1;
            }

        } else if (r1 < r2) {
            return -1;

        } else {
            return 1;
        }

    }
}
