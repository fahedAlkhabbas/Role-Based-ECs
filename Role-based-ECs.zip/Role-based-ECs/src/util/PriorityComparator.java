package util;

import com.intendico.gorite.Executor;
import ec.core.agent.EmergentConfigurationsManager;

import java.util.AbstractMap;
import java.util.Comparator;

public class PriorityComparator implements Comparator<AbstractMap.SimpleEntry<Integer, Executor>> {
    @Override
    public int compare(AbstractMap.SimpleEntry<Integer, Executor> o1, AbstractMap.SimpleEntry<Integer, Executor> o2) {

        EmergentConfigurationsManager ecm = EmergentConfigurationsManager.getInstance();


        int requestId1 = o1.getKey();
        int requestId2 = o2.getKey();

        int r1 = ecm.getTeamRolePriorityByRequestId(requestId1);
        int r2 = ecm.getTeamRolePriorityByRequestId(requestId2);
        if (r1 == r2) {
            if (requestId1 < requestId2) {
                return -1;
            } else {
                return 1;
            }

        } else if (r1 > r2) {
            return -1;

        } else {
            return 1;
        }

    }
}
