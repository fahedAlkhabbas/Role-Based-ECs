package util;

import com.intendico.gorite.Capability;

import java.util.HashMap;

public class Settings {


    public static final String REQUEST_ID = "REQUEST_ID";
    public static final String TYPE = "TYPE";
    public static final String ABSTRACT = "ABSTRACT";
    public static final String CONCRETE = "CONCRETE";







    // agents capabilities.

    public static final String ADJUST_LIGHT_AUTONOMOUSLY = "ADJUST_LIGHT_AUTONOMOUSLY";
    public static final String MAINTAIN_TEMPERATURE_AUTONOMOUSLY = "MAINTAIN_TEMPERATURE_AUTONOMOUSLY";
    public static final String ANALYZE_INCIDENT_AUTONOMOUSLY = "ANALYZE_INCIDENT_AUTONOMOUSLY";
    public static final String CONFIGURE_DISPLAY_AUTONOMOUSLY = "CONFIGURE_DISPLAY_AUTONOMOUSLY";
    public static final String STREAM_ADD_AUTONOMOUSLY = "STREAM_ADD_AUTONOMOUSLY";
    public static final String DISPLAY_INFO_AUTONOMOUSLY = "DISPLAY_INFO_AUTONOMOUSLY";
    public static final String PROVIDE_BOAT_ADD_INFO_AUTONOMOUSLY = "PROVIDE_BOAT_ADD_INFO_AUTONOMOUSLY";
    public static final String COLLECT_INFO_AUTONOMOUSLY = "COLLECT_INFO_AUTONOMOUSLY";


    public static final String DESIRED_TEMPERATURE = "DESIRED_TEMPERATURE";






    public static final String PUBLISH_DISCOUNTS_AUTONOMOUSLY = "PUBLISH_DISCOUNTS_AUTONOMOUSLY";

    // agents' goals
    public static final String ADJUST_LIGHT_LEVEL = "ADJUST_LIGHT_LEVEL";
    public static final String ADJUST_TEMPERATURE_LEVEL = "ADJUST_TEMPERATURE_LEVEL";
    public static final String MAINTAIN_TEMPERATURE = "MAINTAIN_TEMPERATURE";
    public static final String CONFIGURE_DISPLAY_MEDIA = "CONFIGURE_DISPLAY_MEDIA";

    public static final String STREAM_ADVERTISEMENT = "STREAM_ADVERTISEMENT";
    public static final String INFO_ANALYSIS = "INFO_ANALYSIS";
    public static final String COLLECT_INFO = "COLLECT_INFO";
    public static final String DISCOUNTS_ADVERTISEMENT = "DISCOUNTS_ADVERTISEMENT";
    public static final String DISPLAY_ADVERTISEMENT = "DISPLAY_ADVERTISEMENT";
    public static final String PROVIDE_BOATS_AD_INFO = "PROVIDE_BOATS_AD_INFO";
    public static final String ADS_STREAMER_ROLE = "ADS_STREAMER_ROLE";
    public static final String ADS_VIEWER_ROLE = "ADS_VIEWER_ROLE";
    public static final String ADS_INFO_PROVIDER_ROLE = "ADS_INFO_PROVIDER_ROLE";


    public static final String INFO_PROVIDER_ROLE = "INFO_PROVIDER_ROLE";
    public static final String INCIDENT_INFO_PROVIDER = "INCIDENT_INFO_PROVIDER";


    public static final String DISCOUNT_PUBLISHER_ROLE = "DISCOUNT_PUBLISHER_ROLE";
    public static final String INCIDENT_ANALYZER_ROLE = "INCIDENT_ANALYZER_ROLE";


    // agents' roles
    public static final String LIGHT_LEVEL_ADJUSTER = "LIGHT_LEVEL_ADJUSTER";
    public static final String DISPLAY_CONFIGURATOR = "DISPLAY_CONFIGURATOR";
    public static final String ADJUST_LIGHT_CONCRETE_SCHEMA = "AdjustLightConcreteSchema";
    public static final String MANAGE_TEMPERATURE_CONCRETE_SCHEMA = "MaintainTemperatureConcreteSchema";
    public static final String ANALYZE_INCIDENT_CONCRETE_SCHEMA = "AnalyzeIncidentConcreteSchema";
    public static final String CONFIUGRE_DISPLAY_CONCRETE_SCHEMA = "ConfigureDisplayConcreteSchema";
    public static final String COLLECT_INCIDENT_INFO_CONCRETE_SCHEMA = "CollectIncidentInfoConcreteSchema";
    public static final String GIVE_PRESENTATION_ABSTRACT_SCHEMA = "GivePresentationAbstractSchema";
    public static final String ADVERTISE_BOAT_ADS_ABSTRACT_SCHEMA = "AdvertiseBoatAdsAbstractSchema";
    public static final String ADJUST_LIGHT_LEVEL_ABSTRACT_SCHEMA = "AdjustLightLevelAbstractSchema";
    public static final String ADVERTISE_MUSEUM_ADS_ABSTRACT_SCHEMA = "AdvertiseMuseumAbstractSchema";
    public static final String MANAGE_INCIDENT_ABSTRACT_SCHEMA = "ManageIncidentAbstractSchema";

    public static final String STREAM_AD_CONCRETE_SCHEMA = "StreamAdsConcreteSchema";
    public static final String DISPLAY_INFO_CONCRETE_SCHEMA = "DisplayInfoConcreteSchema";
    public static final String PROVIDE_AD_INFO_CONCRETE_SCHEMA = "BoatAdsInfoConcreteSchema";


    public static final String PUBLISH_DISCOUNTS_CONCRETE_SCHEMA = "PublishDiscountsConcreteSchema";


    public static final String ECMToDoGroup = "ECMToDoGroup";
    public static final String todogroup = "todogroup";

    public static final String ADJUST_LIGHT = "ADJUST_LIGHT";
    public static final String DISPLAY_INFO = "DISPLAY_INFO";
    public static final String PROVIDE_LIVE_INFO = "PROVIDE_LIVE_INFO";
    public static final String CONFIGURE_DISPLAY = "CONFIGURE_DISPLAY";
    public static final String TRAIN = "TRAIN";


    public static final String STATUS = "STATUS";
    public static final String ACTIVE = "ACTIVE";
    public static final String UNDER_EXECUTION = "UNDER_EXECUTION";
    public static final String COMPLETED = "COMPLETED";
    public static final String SUSBENDED = "SUSBENDED";

    public static final String GIVE_PRESENTATION = "GIVE_PRESENTATION";
    public static final String SET_LIGHT_LEVEL = "SET_LIGHT_LEVEL";
    public static final String GOAL_TYPE = "GOAL_TYPE";
    public static final String RESOURCE_CONFLICT = "RESOURCE_CONFLICT";
    public static final String PROVIDE_INFO = "PROVIDE_INFO";
    public static final String INCIDENT_ANALYZER = "INCIDENT_ANALYZER";
    public static final String ANALYZE_INCIDENT = "ANALYZE_INCIDENT";

    

    public static final String ROLE = "ROLE";
    public static final String SMARTSCREEN = "SMARTSCREEN";
    public static final String CAMERA = "CAMERA";
    public static final String SERVER = "SERVER";
    public static final String TEMPSENSORS = "TEMPSENSORS";
    public static final String VSENSORS = "VSENSORS";
    public static final String PSERVERS = "PSERVERS";
    public static final String ADV_ENDED = "ADV_ENDED";
    public static final String SSENSOR = "SSENSOR";




    public static final String ADVERTISEMENT_REQUESTER = "ADVERTISEMENT_REQUESTER";
    public static final String GUEST = "GUEST";
    public static final String SPEAKER = "SPEAKER";
    public static final String AUTHORITY = "AUTHORITY";
    public static final String JANITOR = "JANITOR";








    public static final String SHOW_BOATS_ADS = "SHOW_BOATS_ADS";
    public static final String SHOW_MUSEUM_ADS = "SHOW_MUSEUM_ADS";
    public static final String INCIDENT_ANALYSIS = "INCIDENT_ANALYSIS";
    public static final String ADS_STREAMER = "ADS_STREAMER";
    public static final String STREAM_ADS = "STREAM_ADS";
    public static final String STREAM_PEOPLE_COUNT = "STREAM_PEOPLE_COUNT";
    public static final String STREAM_BOATS_COUNT = "STREAM_BOATS_COUNT";
    public static final String BOATS_COUNTER = "BOATS_COUNTER";
    public static final String PEOPLE_COUNTER = "PEOPLE_COUNTER";
    public static final String MEASURE_TEMERATURE = "MEASURE_TEMERATURE";
    public static final String TEMPARATURE_REPORTER = "TEMPARATURE_REPORTER";
    public static final String TEMPARATURE_ADJUSER = "TEMPARATURE_ADJUSER";
    public static final String LIVE_INFO = "LIVE_INFO";
    public static final String END_AD = "END_AD";
    public static final String GOAL_END = "GOAL_END";
    public static final String BEACON = "BEACON";


    public static final String PUBLISH_DISCOUNTS = "PUBLISH_DISCOUNTS";
    public static final String DISCOUNTS_PUBLISHER = "DISCOUNTS_PUBLISHER";
    public static final String FORMED = "FORMED";
    public static final String BEING_ENACTED = "BEING_ENACTED";
    public static final String CANT_FORM = "CANT_FORM";


    public static final String TEAM_X = "TEAM_X";
    public static final String SUB_TEAM_X = "TEAM_X";
    public static final String PRESENTATION_TEAM = "PRESENTATION_TEAM";
    public static final String PRESENTER = "PRESENTER";
    public static final String VIEWER = "VIEWER";
    public static final String LIGHT_LEVEL_DETECTOR = "LIGHT_LEVEL_DETECTOR";
    public static final String LIGHT_LEVEL_CONTROLLER = "LIGHT_LEVEL_CONTROLLER";
    public static final String TEMPERATURE_ACTUATOR = "TEMPERATURE_ACTUATOR";
    public static final String USER_AGENT = "USER_AGENT";
    public static final String LOCATION = "LOCATION";


    public static final String EXP_TEAM = "EXP_TEAM";
    public static final String PERFORM_EXP = "PERFORM_EXP";


    public static final String TRUE = "TRUE";
    public static final String FALSE = "FALSE";


    public static final String AGENT_AVAILABLE = "AVAILABLE";
    public static final String AGENT_UNAVAILABLE = "UNAVAILABLE";


    public static final String ON = "ON";
    public static final String OFF = "OFF";
    public static final String LIGHT_LEVEL = "LIGHT_LEVEL";

    public static final String CONNECTED = "CONNECTED";
    public static final String DISCONNECTED = "DISCONNECTED";

    public static final String RUNNING_OUT_OF_BATTERY = "RUNNING_OUT_OF_BATTERY";
    public static final String BATTERY_AVAILABLE = "BATTERY_AVAILABLE";


    public static final int LIGHT_LEVEL_THRESHOLD = 10;
    public static final int BATTERY_THRESHOLD = 10;
    public static final String Presentation_Ended = "Presentation_Ended";


    public static final String PROJECTOR = "Projector";
    public static final String SMARTHPONE = "Smartphone";
    public static final String RASPBERRYPI = "RASPBERRYPI";
    public static final String LAPTOP = "Laptop";


    public static final String STREAM_PRESENTATION = "STREAM_PRESENTATION";
    public static final String DISPLAY_STREAM = "DISPLAY_STREAM";
    public static final String DETECT_LIGHT_LEVEL = "DETECT_LIGHT_LEVEL";
    public static final String CONTROL_LIGHT_LEVEL = "CONTROL_LIGHT_LEVEL";
    public static final String CONTROL_TِEMPERATURE = "CONTROL_TِEMPERATURE";
    public static final String CLOSE_CURTAINS = "CLOSE_CURTAINS";
    public static final String END_PRESENTATION = "END_PRESENTATION";
    public static final String TURN_ON_DEVICE = "TURN_ON_DEVICE";


    public static final String OPERATIONAL_STATUS = "OPERATIONAL_STATUS";
    public static final String CONNECTION_STATUS = "CONNECTION_STATUS";


    public static final String OPEN = "OPEN";
    public static final String CLOSED = "CLOSED";
    public static final String PARTIALLY_CLOSED = "PARTIALLY_CLOSED";

    public static  HashMap<String, Capability> capabilitiesNames = new HashMap<String, Capability>();



}
